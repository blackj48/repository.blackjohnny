import xbmcgui
import xbmcplugin
import sys

dialog = xbmcgui.Dialog()
dialog.ok("Blackjohnny Wizard", "Η εγκατάσταση ήταν επιτυχής!")
