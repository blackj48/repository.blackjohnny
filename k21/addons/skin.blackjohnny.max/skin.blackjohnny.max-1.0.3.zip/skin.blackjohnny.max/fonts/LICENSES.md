# Fonts

## Περιεχόμενα

    Roboto-Light.ttf      Roboto-Regular.ttf   Roboto-Medium.ttf
    Roboto-Bold.ttf       Roboto-Italic.ttf     — Apache 2.0
    GFSDidot.ttf                                — SIL OFL 1.1

Και οι δύο άδειες επιτρέπουν εμπορική αναδιανομή. Τα `LICENSE-Roboto.txt` και
`OFL-GFSDidot.txt` πρέπει να διανέμονται μαζί με τα αρχεία.

## Το type system

| Ρόλος | Οικογένεια | Μεγέθη |
|---|---|---|
| Display / τίτλοι / αποφθέγματα | GFS Didot | 28px και πάνω |
| UI, labels, λίστες, OSD | Roboto | κάτω από 28px |

## Γιατί όχι Cinzel / Marcellus / Playfair

Το εγκεκριμένο design υπονοεί classical Latin display serif. Ελέγχθηκαν τρεις·
**καμία δεν έχει ελληνικά γράμματα**:

    Marcellus          368 glyphs — λείπουν Α α ω Ά ό
    Cinzel             367 glyphs — λείπουν Α α ω Ά ό
    Playfair Display   659 glyphs — λείπουν Α α ω Ά ό

Ένα skin με ελληνικό UI δεν μπορεί να τις χρησιμοποιήσει. Δεν είναι θέμα γούστου.

## Γιατί GFS Didot

- Greek Font Society, σχεδιασμένη **για** ελληνικά
- Πραγματική Didone: η υψηλή αντίθεση πάχους που θέλει το design
- Καλύπτει πολυτονικό — απαραίτητο, το «Γνῶθι σαυτόν» περιέχει U+1FF6 ῶ
- Στατική (όχι variable), άρα προβλέψιμη απόδοση στο FreeType του Kodi

Περιορισμός: **μόνο Regular βάρος**. Ιεραρχία μέσω μεγέθους και χρώματος, όχι bold.
Το synthetic bold σε Didone σπάει τις λεπτές γραμμές.

## Γιατί η Didot κόβεται στα 28px

Οι hairlines μιας Didone εξαφανίζονται σε μικρά μεγέθη σε τηλεόραση από απόσταση
θέασης. Menu labels και κάτω μένουν σε Roboto. Σκόπιμη απόκλιση από το mockup,
για 10-foot legibility.

## Έλεγχος

Το `validate_xml.py` αποτυγχάνει αν κάποιο `<filename>` λείπει από εδώ.
