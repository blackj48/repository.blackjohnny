# Media assets

Το Kodi συμπιέζει αυτόν τον φάκελο σε `Textures.xbt` κατά το build. Τα PNG εδώ είναι
τα sources. **Χωρίς αυτά το skin δεν φορτώνει.**

Το `validate_xml.py` επαληθεύει ότι κάθε `<texture>` που αναφέρεται στα XML υπάρχει εδώ,
και τυπώνει τη λίστα των ελλειπόντων. Τρέξ' το για να δεις τι λείπει αυτή τη στιγμή.

## Απαιτούμενα

### controls/
    button.png, button-focus.png        260x130  9-slice, στρογγυλεμένη γωνία 8px
    panel.png, panel-focus.png          40x40    9-slice
    glow.png                            80x80    χρυσό glow για focus borders
    scrollbar_bg.png                    20x40
    scrollbar.png, scrollbar-focus.png  20x40
    separator.png                       4x2      οριζόντια γραμμή
    check.png, radio-on.png, radio-off.png  32x32

### overlays/
    gradient.png    1920x1080  διαφανές -> μαύρο, από πάνω προς τα κάτω
    vignette.png    1920x1080  διαφανές κέντρο -> μαύρες άκρες
    shadow.png      40x40      9-slice drop shadow
    scanline.png    4x4        προαιρετικό

### backgrounds/
    home.jpg movies.jpg tvshows.jpg livetv.jpg sports.jpg
    music.jpg kids.jpg tools.jpg addons.jpg settings.jpg
    1920x1080, σκοτεινά, χαμηλής αντίθεσης — κείμενο πρέπει να διαβάζεται από πάνω

### logos/
    blackjohnny-max.png     600x120  διαφανές
    blackjohnny-mark.png    120x120  τετράγωνο mark

### icons/
    movies tvshows livetv sports music kids addons settings
    favourites recent search weather tools downloads power profile
    clean backup restore system update network log
    128x128 PNG, μονόχρωμα λευκά (το skin τα χρωματίζει με colordiffuse)

### weather/
    0.png ... 47.png, na.png     128x128 (κωδικοί weather condition του Kodi)

### views/
    list.png poster.png wall.png fanart.png default.png    64x64

### flags/
    Video codec, resolution, audio channel badges. Προαιρετικό στο Phase 1.

## Σημείωση για τα εικονίδια

Σχεδίασέ τα **λευκά και αδιαφανή**. Το skin εφαρμόζει `colordiffuse` για χρυσό στο focus
και dim στο unfocus. Έτσι ένα set εικονιδίων εξυπηρετεί όλα τα themes — αν είναι ήδη
χρυσά, το OLED variant δεν μπορεί να τα φωτίσει.
