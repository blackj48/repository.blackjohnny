# -*- coding: utf-8 -*-
"""BLACKJOHNNY MAX - Αγαπημένα της Μουσικής (MUSIC11, STAGE1).

    RunScript(special://skin/resources/bj_music_state.py,pin,<key>[,<row>])   Info / ☆
    RunScript(special://skin/resources/bj_music_state.py,open,<key>)          a route click

State = ENTITY KEYS only, in skin strings:
    bj.music.pins            «;genre:deep_house;menu:radio_search;» (pin keys, at most max_pins)
    bj.music.history         open keys, most recent first, each once, at most `history`
    bj.music.recent.1..N     what Πρόσφατα shows: the history WITHOUT the pinned entities
                             (owner, 29 Sep: a pinned card is already in the first row),
                             at most N = slots
    bj.music.recent.N.pin    that slot's pin key, delimited
    bj.music.recents         the slots' keys joined «;a;b;» (the section's guard reads it)
Owner's rules (29 Sep): no duplicate in Πρόσφατα - opening a card again moves it to the
front; a small limit (8 shown, 12 remembered) so it never becomes a history dump.
A key is accepted only when resources/bj_music_keys.json (written by g28 from the same
data as the cards) lists it; keys of cards that no longer exist are dropped on the next
write. Never stored: a path, a URL, an add-on id, anything a provider sends.

Never: network, files other than bj_music_keys.json (read), logs, other add-ons'
settings, Kodi settings, background work. Runs only when the user pins or opens.
"""
import json
import os
import sys

TOOL_VERSION = "2026-09-29.2"
SCHEMA = "bjmax.music_keys/1"
PINS = "bj.music.pins"
SLOT = "bj.music.recent.%d"
SLOT_PIN = "bj.music.recent.%d.pin"
RECENTS = "bj.music.recents"
HISTORY = "bj.music.history"
SEP = ";"                    # never «|»: Kodi reads it as OR inside a condition

T = {
    "title": "Αγαπημένα",
    "pinned": "Καρφιτσώθηκε · %s",
    "unpinned": "Αφαιρέθηκε από τα Καρφιτσωμένα · %s",
    "full": "Έως %d καρφιτσωμένα. Αφαίρεσε ένα πρώτα (πλήκτρο Info ή «Καρφιτσωμένο»).",
}


def load_keys(text):
    data = json.loads(text)
    if data.get("schema") != SCHEMA:
        raise ValueError("bj_music_keys.json: schema")
    return data


def split_pins(value, known):
    """The pins string as a list, known keys only, each once, in stored order."""
    out = []
    for k in (value or "").split(SEP):
        if k and k in known and k not in out:
            out.append(k)
    return out


def join_pins(keys):
    return SEP + SEP.join(keys) + SEP if keys else ""


def load_history(get, keys):
    """The remembered open keys, known ones only, each once. A MUSIC11 state has no
    history yet: its slots are the history."""
    hist = split_pins(get(HISTORY), keys["open"])
    if not hist:
        for n in range(1, int(keys["slots"]) + 1):
            k = (get(SLOT % n) or "").strip().lower()
            if k in keys["open"] and k not in hist:
                hist.append(k)
    return hist[:int(keys["history"])]


def write_recents(get, skin, keys, hist, pins):
    """Writes the history and what Πρόσφατα shows; returns the shown keys."""
    slots = int(keys["slots"])
    shown = [k for k in hist if keys["open"][k]["pin"] not in pins][:slots]
    new = (shown + [""] * slots)[:slots]
    writes = [(HISTORY, join_pins(hist)), (RECENTS, join_pins(shown))]
    for n, now in enumerate(new, 1):
        writes += [(SLOT % n, now), (SLOT_PIN % n, SEP + keys["open"][now]["pin"] + SEP if now else "")]
    for name_, value in writes:
        if (get(name_) or "") != value:
            skin("Skin.SetString(%s,%s)" % (name_, value) if value else "Skin.Reset(%s)" % name_)
    return shown


def run(argv, keys, get, skin, ui, name):
    """argv: [script, mode, key, (row)]; get(skin string name) -> value; skin(builtin);
    ui.say(text); ui.focus(control id); name(label id) -> the card's name.
    Returns 0 when handled, 1 when refused."""
    mode = argv[1] if len(argv) > 1 else ""
    key = (argv[2] if len(argv) > 2 else "").strip().lower()
    row = (argv[3] if len(argv) > 3 else "").strip()
    rows = keys["rows"]
    if mode == "pin":
        if key in keys["open"]:                  # a Πρόσφατα card pins the entity it belongs to
            key = keys["open"][key]["pin"]
        if key not in keys["pin"]:
            return 1
        pins = split_pins(get(PINS), keys["pin"])
        if key in pins:
            pins.remove(key)
            said = T["unpinned"] % name(keys["pin"][key])
        elif len(pins) >= int(keys["max_pins"]):
            ui.say(T["full"] % int(keys["max_pins"]))
            return 1
        else:
            pins.append(key)
            said = T["pinned"] % name(keys["pin"][key])
        value = join_pins(pins)
        skin("Skin.SetString(%s,%s)" % (PINS, value) if value else "Skin.Reset(%s)" % PINS)
        shown = write_recents(get, skin, keys, load_history(get, keys), pins)
        ui.say(said)
        # the row the user acted in may just have emptied (its card moved to the other
        # row): the focus goes where the card went, never to a hidden list
        if row == str(rows["recent"]) and not shown:
            ui.focus(rows["pinned"])
        elif row == str(rows["pinned"]) and not pins:
            ui.focus(rows["recent"] if shown else rows["sidebar"])
        return 0
    if mode == "open":
        if key not in keys["open"]:
            return 1
        hist = ([key] + [k for k in load_history(get, keys) if k != key])[:int(keys["history"])]
        write_recents(get, skin, keys, hist, split_pins(get(PINS), keys["pin"]))
        return 0
    return 1


def main(argv):
    import xbmc
    import xbmcgui
    here = os.path.dirname(os.path.abspath(__file__))
    with open(os.path.join(here, "bj_music_keys.json"), encoding="utf-8") as fh:
        keys = load_keys(fh.read())

    class UI(object):
        def say(self, text):
            xbmcgui.Dialog().notification(T["title"], text, xbmcgui.NOTIFICATION_INFO, 3000)

        def focus(self, cid):
            xbmc.sleep(200)                # one frame for the rows to follow the new strings
            xbmc.executebuiltin("SetFocus(%d)" % int(cid))

    return run(argv, keys, lambda s: xbmc.getInfoLabel("Skin.String(%s)" % s), xbmc.executebuiltin, UI(),
               lambda lid: xbmc.getLocalizedString(int(lid)))


if __name__ == "__main__":
    sys.exit(main(sys.argv))
