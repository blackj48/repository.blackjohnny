# -*- coding: utf-8 -*-
"""BLACKJOHNNY MAX - Greek keyboard layout on demand (KBGR, D162).

    RunScript(special://skin/resources/bj_keyboard.py,<mode>)
      status   read-only: publishes the state for the Εργαλεία tile
      toggle   the user pressed «Ελληνικό πληκτρολόγιο»

Kodi's keyboard (GUIDialogKeyboardGeneric) cycles only the layouts listed in
Kodi's own setting `locale.keyboardlayouts` (max 3). The skin cannot add one by
itself, so this script does it - and only when the user presses the tile:
  absent  -> Greek is ADDED next to what is there (nothing removed), read back,
             and the result is shown;
  present -> the user is asked; on «yes» Greek is removed (never the last one).
Kodi then cycles EN <-> ΕΛ with the keyboard's layout key.

Touches exactly two Kodi settings, `locale.keyboardlayouts` and (on removal)
`locale.activekeyboardlayout`, through local JSON-RPC. Never: network, files,
other add-ons' settings, background work, anything at startup.
Skin state written: Skin.SetBool/Reset(bj.kb.greek), Skin.SetString(bj.kb.layouts).
"""
import json
import sys

TOOL_VERSION = "2026-09-29.1"
SETTING = "locale.keyboardlayouts"
ACTIVE = "locale.activekeyboardlayout"
GREEK = "Greek"              # the language attribute in system/keyboardlayouts/greek.xml
FALLBACK = "Greek QWERTY"    # the layout's name when Kodi does not list the options
MAX_LAYOUTS = 3              # settings.xml: <maximumitems>3</maximumitems>

T = {
    "title": "Ελληνικό πληκτρολόγιο",
    "added": "Ενεργό: %s · άλλαξε διάταξη με το πλήκτρο διάταξης",
    "remove_q": "Η ελληνική διάταξη είναι ενεργή (%s). Να αφαιρεθεί;",
    "removed": "Αφαιρέθηκε · έμεινε: %s",
    "full": "Υπάρχουν ήδη 3 διατάξεις (%s). Αφαίρεσε μία από τις ρυθμίσεις του Kodi πρώτα.",
    "failed": "Το Kodi δεν δέχτηκε την αλλαγή. Τίποτα δεν άλλαξε.",
    "none": "Το Kodi δεν έχει ελληνική διάταξη πληκτρολογίου.",
}


def greek_name(options):
    """The Greek layout as Kodi names it (the settings filler's values)."""
    for o in options or []:
        v = o.get("value") if isinstance(o, dict) else o
        if isinstance(v, str) and v.startswith(GREEK + " "):
            return v
    return FALLBACK if not options else None


def publish(skin, layouts, name):
    on = bool(name) and name in layouts
    skin("Skin.SetBool(bj.kb.greek)" if on else "Skin.Reset(bj.kb.greek)")
    skin('Skin.SetString(bj.kb.layouts,"%s")' % " · ".join(layouts).replace('"', ""))
    return on


def run(argv, rpc, ui, skin):
    mode = argv[1] if len(argv) > 1 else "status"
    layouts = [v for v in (rpc("Settings.GetSettingValue", {"setting": SETTING}) or {}).get("value", []) if v]
    name = greek_name(rpc_options(rpc))
    if mode != "toggle":
        publish(skin, layouts, name)
        return 0
    if not name:
        ui.say(T["none"])
        return 1
    if name not in layouts:
        if len(layouts) >= MAX_LAYOUTS:
            ui.say(T["full"] % ", ".join(layouts))
            return 1
        want = layouts + [name]
    else:
        rest = [v for v in layouts if v != name]
        if not rest or not ui.yesno(T["remove_q"] % ", ".join(layouts)):
            publish(skin, layouts, name)
            return 0
        want = rest
    rpc("Settings.SetSettingValue", {"setting": SETTING, "value": want})
    now = (rpc("Settings.GetSettingValue", {"setting": SETTING}) or {}).get("value", [])
    if list(now) != want:                      # read back: say only what Kodi really holds
        ui.say(T["failed"])
        publish(skin, list(now), name)
        return 1
    if name not in want:
        rpc("Settings.SetSettingValue", {"setting": ACTIVE, "value": want[0]})
    publish(skin, want, name)
    ui.say((T["added"] if name in want else T["removed"]) % " + ".join(want))
    return 0


def rpc_options(rpc):
    """The options Kodi offers for the setting (its keyboard layout list)."""
    res = rpc("Settings.GetSettings", {"level": "expert", "filter": {"section": "interface", "category": "regional"}}) or {}
    for s in res.get("settings", []):
        if s.get("id") == SETTING:
            d = s.get("definition") or {}
            return d.get("options") or s.get("options") or []
    return []


def main(argv):
    import xbmc
    import xbmcgui

    def rpc(method, params):
        raw = xbmc.executeJSONRPC(json.dumps({"jsonrpc": "2.0", "id": 1, "method": method, "params": params}))
        try:
            return json.loads(raw).get("result")
        except ValueError:
            return None

    dialog = xbmcgui.Dialog()

    class UI(object):
        def yesno(self, text):
            return dialog.yesno(T["title"], text)

        def say(self, text):
            dialog.notification(T["title"], text, xbmcgui.NOTIFICATION_INFO, 6000)

    return run(argv, rpc, UI(), xbmc.executebuiltin)


if __name__ == "__main__":
    sys.exit(main(sys.argv))
