"""User-confirmed emergency exit of THIS Kodi process, Windows only.

No taskkill, process-name wildcard, shell command, external player termination,
shutdown, deletion or restart. _exit intentionally skips shutdown handlers.
"""
import ctypes
import os
import xbmc
import xbmcgui


def is_kodi_process():
    if os.name != 'nt':
        return False
    buffer = ctypes.create_unicode_buffer(32768)
    get_name = ctypes.windll.kernel32.GetModuleFileNameW
    get_name.argtypes = [ctypes.c_void_p, ctypes.c_wchar_p, ctypes.c_uint32]
    get_name.restype = ctypes.c_uint32
    length = get_name(None, buffer, len(buffer))
    return 0 < length < len(buffer) and os.path.basename(buffer.value).lower() == 'kodi.exe'


def main():
    if not is_kodi_process():
        xbmcgui.Dialog().ok('BLACKJOHNNY MAX', xbmc.getLocalizedString(31840))
        return
    confirmed = xbmcgui.Dialog().yesno(
        xbmc.getLocalizedString(31836), xbmc.getLocalizedString(31837),
        nolabel=xbmc.getLocalizedString(31838),
        yeslabel=xbmc.getLocalizedString(31839))
    if confirmed:
        os._exit(0)


if __name__ == '__main__':
    main()
