"""Home from a skin button, using Kodi's normal cancel/back action for dialogs.

No Dialog.Close(all), synthetic OK clicks, player stop, profile writes or
credential access. If a dialog refuses Back, or reveals another modal, leave
that modal to the user rather than accepting an unknown confirmation.

24 Sep 2026 (lyrics incident): an add-on's own Python window (ids 13000-13099,
window or dialog) is never navigated away from underneath. It gets one Back;
if it is still there, the user is told to close it - no forced ActivateWindow.
"""
import xbmc
import xbmcgui

PYTHON_WINDOWS = range(13000, 13100)
NOTE_ID = 31917


def is_blocking(window_id, dialog_id):
    """Pure: True while something Home must not navigate away from."""
    return dialog_id > 9999 or window_id in PYTHON_WINDOWS


def main():
    home = xbmcgui.Window(10000)
    if home.getProperty('Cinema.HomeBusy'):
        return
    home.setProperty('Cinema.HomeBusy', 'true')
    try:
        before = (xbmcgui.getCurrentWindowId(), xbmcgui.getCurrentWindowDialogId())
        if is_blocking(*before):
            xbmc.executebuiltin('Action(back)', True)
            monitor = xbmc.Monitor()
            for _ in range(15):
                if (xbmcgui.getCurrentWindowId(), xbmcgui.getCurrentWindowDialogId()) != before:
                    break
                if monitor.waitForAbort(0.05):
                    return
            if is_blocking(xbmcgui.getCurrentWindowId(), xbmcgui.getCurrentWindowDialogId()):
                # A nested dialog, a save prompt or an add-on window: the user decides.
                xbmcgui.Dialog().notification('BLACKJOHNNY MAX', xbmc.getLocalizedString(NOTE_ID))
                return
        xbmc.executebuiltin('ActivateWindow(Home)', True)
    finally:
        home.clearProperty('Cinema.HomeBusy')


if __name__ == '__main__':
    main()
