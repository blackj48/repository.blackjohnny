"""BLACKJOHNNY MAX - local player groups for TMDb Helper (BJMAX-ADR-01).

    RunScript(special://skin/resources/bj_players.py,refresh)
    RunScript(special://skin/resources/bj_players.py,menu)
    RunScript(special://skin/resources/bj_players.py,play,<rd|free>,<tmdb_id>)

ONE EVALUATOR. Button visibility (window properties), the explanation text
and the pre-play check all come from evaluate(), so the menu, the
explanation and the check cannot disagree with each other.

AVAILABILITY mirrors TMDb Helper 6.17.4 (player/config/meta.py): a player is
enabled when it is not "disabled": true and every add-on in its "plugin"
field passes System.AddonIsEnabled. Files are read from players/ and
reconfigured_players/; for the same file name, reconfigured_players/ wins
(files.py basedirs order). Bundled players are not offered: whether TMDb
Helper uses them is a setting, and settings.xml is never opened here.

WHAT A GROUP BUTTON PROMISES: which player is tried FIRST. If that player
fails, TMDb Helper itself tries the player's own "fallback" and then shows
its full player list (player.py more()). The skin cannot and does not claim
to keep playback inside the group.

PRIVACY. No network, no subprocess, no settings.xml. Nothing is logged.
The only thing stored is the classification: Skin.String(bj.players.rd) and
Skin.String(bj.players.free), each a '|'-separated list of percent-encoded
player FILE NAMES. No path, URL, token or title is stored.
"""
import json
import re
import sys
from urllib.parse import quote, unquote

TMDBH = 'plugin.video.themoviedb.helper'
DIRS = ('special://profile/addon_data/plugin.video.themoviedb.helper/players/',
        'special://profile/addon_data/plugin.video.themoviedb.helper/reconfigured_players/')
GROUPS = ('rd', 'free')
SETTING = {'rd': 'bj.players.rd', 'free': 'bj.players.free'}
ROUTE = 'play_movie'
ADDON_ID = re.compile(r'^[a-z0-9][a-z0-9._-]{1,80}$')
SAFE_FILE = re.compile(r'^[A-Za-z0-9._ ()+-]{1,96}\.json$')
TAGS = re.compile(r'\[/?(?:COLOR[^\]]*|B|I|UPPERCASE|LOWERCASE|CAPITALIZE|CR|LIGHT)\]', re.I)

TEXT = {
    'el': {
        'rd': 'Real-Debrid', 'free': 'Δωρεάν', 'players': 'Players',
        'menu_classify': 'Ταξινόμηση players',
        'menu_explain': 'Γιατί λείπει κάποιο κουμπί;',
        'pick_rd': 'Players για το κουμπί Real-Debrid',
        'pick_free': 'Players για το κουμπί Δωρεάν',
        'choose': 'Επίλεξε player',
        'wont_start': 'Δεν θα ξεκινήσει',
        'unavailable': 'μη διαθέσιμο',
        'ok': 'διαθέσιμος',
        'r_tmdbh': 'Το TMDb Helper δεν είναι εγκατεστημένο ή είναι απενεργοποιημένο.',
        'r_empty': 'Δεν έχεις αντιστοιχίσει κανέναν player σε αυτή την ομάδα.',
        'r_none': 'Κανένας από τους players της ομάδας δεν είναι διαθέσιμος τώρα.',
        'r_no_id': 'Ο τίτλος δεν έχει αναγνωριστικό TMDb, οπότε δεν μπορεί να σταλεί σε player.',
        'p_missing': 'το αρχείο του player δεν υπάρχει πια',
        'p_unreadable': 'το αρχείο του player δεν διαβάζεται',
        'p_disabled': 'ο player είναι απενεργοποιημένος στο TMDb Helper',
        'p_route': 'ο player δεν παίζει ταινίες',
        'p_addon': 'το πρόσθετο %s δεν είναι εγκατεστημένο ή ενεργό',
        'h_status': 'Κατάσταση ομάδων',
        'h_unclassified': 'Μη ταξινομημένοι players',
        'h_note': 'Σημείωση',
        'note': ('Το κουμπί ορίζει ποιος player δοκιμάζεται πρώτος. Αν αποτύχει, το '
                 'TMDb Helper δοκιμάζει τον fallback του player και μετά δείχνει όλους '
                 'τους players. Η ομάδα δεν εγγυάται Real-Debrid ούτε προστασία IP· '
                 'αυτά εξαρτώνται από τις ρυθμίσεις κάθε πρόσθετου.'),
        'n_available': 'διαθέσιμοι: %d',
    },
    'en': {
        'rd': 'Real-Debrid', 'free': 'Free', 'players': 'Players',
        'menu_classify': 'Classify players',
        'menu_explain': 'Why is a button missing?',
        'pick_rd': 'Players for the Real-Debrid button',
        'pick_free': 'Players for the Free button',
        'choose': 'Choose a player',
        'wont_start': 'Will not start',
        'unavailable': 'unavailable',
        'ok': 'available',
        'r_tmdbh': 'TMDb Helper is not installed or is disabled.',
        'r_empty': 'No player is assigned to this group.',
        'r_none': 'None of the players in this group is available now.',
        'r_no_id': 'This title has no TMDb id, so it cannot be sent to a player.',
        'p_missing': 'the player file no longer exists',
        'p_unreadable': 'the player file cannot be read',
        'p_disabled': 'the player is disabled in TMDb Helper',
        'p_route': 'the player does not play movies',
        'p_addon': 'add-on %s is not installed or not enabled',
        'h_status': 'Group status',
        'h_unclassified': 'Unclassified players',
        'h_note': 'Note',
        'note': ('A button decides which player is tried first. If it fails, TMDb '
                 'Helper tries that player\'s fallback and then shows every player. '
                 'A group does not guarantee Real-Debrid or IP protection; those '
                 'depend on each add-on\'s own settings.'),
        'n_available': 'available: %d',
    },
}


# --- pure logic (no Kodi imports; unit-tested) ------------------------------

def clean_name(value, fallback):
    if not isinstance(value, str):
        return fallback
    text = re.sub(r'\s+', ' ', TAGS.sub('', value)).strip()
    return text[:60] or fallback


def parse_player(raw, filename):
    """Reduce a player JSON to what availability needs. Never returns URLs."""
    try:
        data = json.loads(raw)
    except ValueError:
        return {'file': filename, 'unreadable': True}
    if not isinstance(data, dict):
        return {'file': filename, 'unreadable': True}
    plugins = data.get('plugin') or 'plugin.undefined'
    plugins = plugins if isinstance(plugins, list) else [plugins]
    plugins = [p for p in plugins if isinstance(p, str)] or ['plugin.undefined']
    disabled = str(data.get('disabled', '')).strip().lower() in ('true', '1', 'yes')
    return {'file': filename, 'unreadable': False,
            'name': clean_name(data.get('name'), filename[:-5]),
            'plugins': plugins, 'disabled': disabled,
            'movie': ROUTE in data}


def encode(files):
    return '|'.join(quote(f, safe='') for f in files)


def decode(value):
    out = []
    for part in (value or '').split('|'):
        name = unquote(part)
        if part and SAFE_FILE.match(name) and name not in out:
            out.append(name)
    return out


def player_reasons(meta, addon_enabled):
    """Reason codes why a player cannot be used; empty list = available."""
    if meta is None:
        return [('p_missing', None)]
    if meta.get('unreadable'):
        return [('p_unreadable', None)]
    reasons = []
    if meta['disabled']:
        reasons.append(('p_disabled', None))
    if not meta['movie']:
        reasons.append(('p_route', None))
    for p in meta['plugins']:
        # an id that is not a well-formed add-on id is never passed into a
        # Kodi condition string; it simply counts as not enabled
        if not ADDON_ID.match(p) or not addon_enabled(p):
            reasons.append(('p_addon', p))
    return reasons


def evaluate(players, classification, addon_enabled):
    """players: {file: meta}; classification: {'rd': [file], 'free': [file]}."""
    result = {'tmdbh': addon_enabled(TMDBH), 'groups': {}, 'unclassified': []}
    taken = set()
    for group in GROUPS:
        rows = []
        for f in classification.get(group, []):
            if f in taken:  # a file belongs to one group only; first wins
                continue
            taken.add(f)
            meta = players.get(f)
            rows.append({'file': f, 'name': meta.get('name', f) if meta and not meta.get('unreadable') else f,
                         'reasons': player_reasons(meta, addon_enabled)})
        available = [r for r in rows if not r['reasons']]
        if not result['tmdbh']:
            reason = 'r_tmdbh'
        elif not rows:
            reason = 'r_empty'
        elif not available:
            reason = 'r_none'
        else:
            reason = None
        result['groups'][group] = {'rows': rows, 'available': available, 'reason': reason}
    result['unclassified'] = sorted(f for f in players if f not in taken)
    return result


def play_url(tmdb_id, player_file):
    # Verified against TMDb Helper 6.17.4: info=play routes to play_player();
    # player+mode build the forced "<file> play_movie" entry; ignore_default
    # makes the forced player the only queued default (player/dialog/default.py).
    return ('plugin://%s/?info=play&tmdb_type=movie&tmdb_id=%s&player=%s'
            '&mode=play&ignore_default=true' % (TMDBH, tmdb_id, quote(player_file, safe='')))


def explanation(result, t):
    lines = ['[B]%s[/B]' % t['h_status']]
    for group in GROUPS:
        g = result['groups'][group]
        state = t[g['reason']] if g['reason'] else t['n_available'] % len(g['available'])
        lines.append('%s: %s' % (t[group], state))
        for row in g['rows']:
            if row['reasons']:
                why = '; '.join((t[c] % arg) if arg else t[c] for c, arg in row['reasons'])
                lines.append('    - %s: %s' % (row['name'], why))
            else:
                lines.append('    - %s: %s' % (row['name'], t['ok']))
    lines += ['', '[B]%s[/B]: %d' % (t['h_unclassified'], len(result['unclassified'])),
              '', '[B]%s[/B]' % t['h_note'], t['note']]
    return '\n'.join(lines)


# --- Kodi side ----------------------------------------------------------------

def _kodi():
    import xbmc
    import xbmcgui
    import xbmcvfs
    return xbmc, xbmcgui, xbmcvfs


def _texts(xbmc):
    try:
        lang = xbmc.getLanguage(xbmc.ISO_639_1)
    except Exception:
        lang = 'en'
    return TEXT['el' if lang == 'el' else 'en']


def discover(xbmcvfs):
    players = {}
    for folder in DIRS:  # later folder wins, as in TMDb Helper
        if not xbmcvfs.exists(folder):
            continue
        _dirs, files = xbmcvfs.listdir(folder)
        for name in files:
            if not SAFE_FILE.match(name):
                continue
            handle = xbmcvfs.File(folder + name)
            try:
                raw = handle.read()
            finally:
                handle.close()
            players[name] = parse_player(raw, name)
    return players


def current(xbmc, xbmcvfs):
    players = discover(xbmcvfs)
    classification = {g: decode(xbmc.getInfoLabel('Skin.String(%s)' % SETTING[g])) for g in GROUPS}
    enabled = lambda addon: bool(xbmc.getCondVisibility('System.AddonIsEnabled(%s)' % addon))
    return players, evaluate(players, classification, enabled)


def publish(xbmcgui, result):
    home = xbmcgui.Window(10000)
    for group in GROUPS:
        g = result['groups'][group]
        # the same verdict play() uses: a group is usable only without a reason
        home.setProperty('bj.play.%s' % group, 'true' if g['reason'] is None else '')


def refresh():
    xbmc, xbmcgui, xbmcvfs = _kodi()
    publish(xbmcgui, current(xbmc, xbmcvfs)[1])


def classify():
    xbmc, xbmcgui, xbmcvfs = _kodi()
    t = _texts(xbmc)
    players, result = current(xbmc, xbmcvfs)
    enabled = lambda addon: bool(xbmc.getCondVisibility('System.AddonIsEnabled(%s)' % addon))
    files = sorted(players, key=lambda f: (players[f].get('name') or f).lower())
    chosen = {g: [r['file'] for r in result['groups'][g]['rows'] if r['file'] in players] for g in GROUPS}
    dialog = xbmcgui.Dialog()
    remaining, selections = files, {}
    for group in GROUPS:
        labels = []
        for f in remaining:
            meta = players[f]
            name = meta.get('name', f) if not meta.get('unreadable') else f
            if player_reasons(meta, enabled):
                name = '%s  (%s)' % (name, t['unavailable'])
            labels.append(name)
        pre = [i for i, f in enumerate(remaining) if f in chosen[group]]
        picked = dialog.multiselect(t['pick_' + group], labels, preselect=pre)
        if picked is None:  # cancelled at any step: nothing is written
            return
        selections[group] = [remaining[i] for i in picked]
        remaining = [f for f in remaining if f not in selections[group]]
    for group in GROUPS:  # written only after both steps completed
        if selections[group]:
            xbmc.executebuiltin('Skin.SetString(%s,%s)' % (SETTING[group], encode(selections[group])))
        else:  # an empty Skin.SetString would open a keyboard
            xbmc.executebuiltin('Skin.Reset(%s)' % SETTING[group])
    refresh()


def explain():
    xbmc, xbmcgui, xbmcvfs = _kodi()
    t = _texts(xbmc)
    xbmcgui.Dialog().textviewer(t['players'], explanation(current(xbmc, xbmcvfs)[1], t))


def menu():
    xbmc, xbmcgui, _ = _kodi()
    t = _texts(xbmc)
    choice = xbmcgui.Dialog().select(t['players'], [t['menu_classify'], t['menu_explain']])
    if choice == 0:
        classify()
    elif choice == 1:
        explain()


def play(group, tmdb_id):
    xbmc, xbmcgui, xbmcvfs = _kodi()
    t = _texts(xbmc)
    dialog = xbmcgui.Dialog()
    if group not in GROUPS:
        return
    if not re.match(r'^\d{1,10}$', tmdb_id or ''):
        dialog.ok(t['wont_start'], t['r_no_id'])
        return
    _players, result = current(xbmc, xbmcvfs)  # re-checked right before running
    publish(xbmcgui, result)
    g = result['groups'][group]
    if g['reason']:
        dialog.ok(t['wont_start'], t[g['reason']])
        return
    rows = g['available']
    if len(rows) == 1:
        row = rows[0]
    else:
        index = dialog.select(t['choose'], [r['name'] for r in rows])
        if index < 0:
            return
        row = rows[index]
    xbmc.executebuiltin('RunPlugin(%s)' % play_url(tmdb_id, row['file']))


def main(argv):
    action = argv[1] if len(argv) > 1 else ''
    if action == 'refresh':
        refresh()
    elif action == 'menu':
        menu()
    elif action == 'play' and len(argv) > 3:
        play(argv[2], argv[3])


if __name__ == '__main__':
    main(sys.argv)
