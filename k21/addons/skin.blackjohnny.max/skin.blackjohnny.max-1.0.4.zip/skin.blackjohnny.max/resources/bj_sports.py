# -*- coding: utf-8 -*-
"""BLACKJOHNNY MAX - Sports Center, live resolver (S1). On demand only:

    RunScript(special://skin/resources/bj_sports.py,live)
        when the user opens «Ζωντανά τώρα» (window open, section click,
        «Ανανέωση»);
    RunScript(special://skin/resources/bj_sports.py,play,<channelid>)
        when the user picks a row.

What it does (live):
  * ONE local JSON-RPC read, PVR.GetChannels(alltv) with broadcastnow and
    broadcastnext - Kodi's own "now/next" for every visible TV channel;
  * keeps the broadcasts whose genre is a DVB SPORTS code, compared with
    Kodi's own genre labels (strings 19548-19559) - never by reading titles;
  * writes the result as Home window properties bj.sports.* (session memory
    only: they vanish when Kodi closes), sorted deterministically:
    «Τώρα» by channel number, «Ακολουθεί» by start time, then channel number.
What it does (play): Player.Open with that channel id - nothing else.

What it never does: network access, reading any add-on's settings, logging,
files, background work, polling, guessing a sport from a title, merging EPGs,
or showing a time, channel or «LIVE» that Kodi did not give it.

A Kodi-side failure is never shown as "no sports": the state is «error» and
the skin says so (class name only).
"""
import calendar
import json
import os
import sys
import time

from bj_sports_health import (GENRE_FIRST, GENRE_LAST, IDENTIFIED, SPORTS_FIRST, SPORTS_LAST,
                              classify, demo_clients, parse_utc)

TOOL_VERSION = "2026-09-24.1"
SLOTS = 8                                   # rows per list; the skin draws exactly these
PREFIX = "bj.sports."
LISTS = ("live", "next")
FIELDS = ("title", "channel", "channelid", "time", "sport", "icon")
STATES = ("no_pvr", "no_channels", "no_guide", "no_genre", "quiet", "live", "error")
HOME = 10000


def local_hm(dt_utc):
    """UTC datetime -> "HH:MM" in the OS's local time. No strftime/strptime."""
    t = time.localtime(calendar.timegm(dt_utc.timetuple()))
    return "%02d:%02d" % (t.tm_hour, t.tm_min)


def _row(c, b, sports_labels, sub):
    st, en = parse_utc(b.get("starttime")), parse_utc(b.get("endtime"))
    return {"title": (b.get("title") or b.get("label") or "").strip(),
            "channel": (c.get("label") or "").strip(),
            "channelid": str(int(c["channelid"])),
            "time": "%s–%s" % (local_hm(st), local_hm(en)) if st and en else "",
            "sport": sports_labels[sub] if sub in IDENTIFIED else "",
            "icon": c.get("icon") or "",
            "_num": c.get("channelnumber") or 0,
            "_start": st}


def resolve(rpc, sports_labels, dvb_labels, demo_ids=()):
    """rpc(method, params) -> result dict or None (error). Pure apart from rpc.
    -> {"state", "demo", "error", "live": [rows], "next": [rows]}."""
    out = {"state": "error", "demo": False, "error": "", "live": [], "next": []}
    addons = rpc("Addons.GetAddons", {"type": "kodi.pvrclient", "enabled": True})
    props = rpc("PVR.GetProperties", {"properties": ["available"]})
    if addons is None or props is None:
        out["error"] = "RPC"
        return out
    ids = [a.get("addonid", "") for a in addons.get("addons") or []]
    out["demo"] = any(i in demo_ids for i in ids)
    if not ids or not props.get("available"):
        out["state"] = "no_pvr"
        return out
    res = rpc("PVR.GetChannels", {"channelgroupid": "alltv",
                                  "properties": ["hidden", "channelnumber", "icon",
                                                 "broadcastnow", "broadcastnext"]})
    if res is None:
        out["error"] = "RPC"
        return out
    chans = [c for c in res.get("channels") or [] if not c.get("hidden")]
    if not chans:
        out["state"] = "no_channels"
        return out
    guide = genre = False
    for c in chans:
        for key, dest in (("broadcastnow", "live"), ("broadcastnext", "next")):
            b = c.get(key)
            if not b:
                continue
            guide = True
            kind, sub = classify(b.get("genre"), sports_labels, dvb_labels)
            if kind != "none":
                genre = True
            if kind == "sports":
                out[dest].append(_row(c, b, sports_labels, sub))
    out["live"].sort(key=lambda r: (r["_num"], int(r["channelid"])))
    out["next"].sort(key=lambda r: (r["_start"] is None, r["_start"] or 0, r["_num"], int(r["channelid"])))
    for k in LISTS:
        out[k] = out[k][:SLOTS]
    if out["live"] or out["next"]:
        out["state"] = "live"
    elif not guide:
        out["state"] = "no_guide"
    elif not genre:
        out["state"] = "no_genre"
    else:
        out["state"] = "quiet"
    return out


def publish(setp, clearp, r, updated):
    """Write the whole result; every slot is cleared first, so a row from an
    earlier run can never survive into this one."""
    for k in LISTS:
        for i in range(1, SLOTS + 1):
            for f in FIELDS:
                clearp("%s%s.%d.%s" % (PREFIX, k, i, f))
    for k in LISTS:
        for i, row in enumerate(r[k], 1):
            for f in FIELDS:
                if row[f]:
                    setp("%s%s.%d.%s" % (PREFIX, k, i, f), row[f])
        setp("%s%s.count" % (PREFIX, k), str(len(r[k])))
    setp(PREFIX + "state", r["state"])
    setp(PREFIX + "demo", "1" if r["demo"] else "")
    setp(PREFIX + "error", r["error"])
    setp(PREFIX + "updated", updated)


def main(argv):
    import xbmc
    import xbmcgui

    def rpc(method, params):
        raw = xbmc.executeJSONRPC(json.dumps({"jsonrpc": "2.0", "id": 1, "method": method, "params": params}))
        try:
            return json.loads(raw).get("result")
        except ValueError:
            return None

    mode = argv[1] if len(argv) > 1 else "live"
    if mode == "play":
        arg = argv[2] if len(argv) > 2 else ""
        if arg.isdigit() and int(arg) > 0:
            rpc("Player.Open", {"item": {"channelid": int(arg)}})
        return 0
    if mode != "live":
        return 0
    home = xbmcgui.Window(HOME)
    home.setProperty(PREFIX + "busy", "1")
    try:
        sports = [xbmc.getLocalizedString(i) for i in range(SPORTS_FIRST, SPORTS_LAST + 1)]
        dvb = [xbmc.getLocalizedString(i) for i in range(GENRE_FIRST, GENRE_LAST + 1)
               if not SPORTS_FIRST <= i <= SPORTS_LAST]
        here = os.path.dirname(os.path.abspath(__file__))
        try:
            r = resolve(rpc, sports, dvb, demo_clients(here))
        except Exception as exc:         # reported, never silent; class name only
            r = {"state": "error", "demo": False, "error": type(exc).__name__, "live": [], "next": []}
        t = time.localtime()
        publish(home.setProperty, home.clearProperty, r, "%02d:%02d" % (t.tm_hour, t.tm_min))
    finally:
        home.clearProperty(PREFIX + "busy")
    return 0


if __name__ == "__main__":
    sys.exit(main(sys.argv))
