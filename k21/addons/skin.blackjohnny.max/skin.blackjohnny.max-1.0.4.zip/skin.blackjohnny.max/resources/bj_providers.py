# -*- coding: utf-8 -*-
"""BLACKJOHNNY MAX - provider actions that change Kodi state, always confirmed.

    RunScript(special://skin/resources/bj_providers.py,enable,<provider_key>)
    RunScript(special://skin/resources/bj_providers.py,install,<provider_key>)

The skin passes a provider KEY; the add-on id is resolved here from the
providers.json shipped next to this script (the only place ids live). The
script never reads another add-on's settings, never touches the network and
writes nothing: Kodi performs the install/enable after the user confirms.
"""
import json
import os
import re
import sys

KEY = re.compile(r"^[a-z][a-z0-9_]{1,31}$")
ID = re.compile(r"^[a-z0-9][a-z0-9._-]{2,80}$")


def load(path):
    with open(path, "r", encoding="utf-8") as fh:
        data = json.load(fh)
    # SPORTS3: the sports providers (providers.json v3 «sports_providers») use the
    # same confirmed path; keys are unique across both lists (the generator refuses clashes).
    return {p["key"]: p for p in data.get("providers", []) + data.get("sports_providers", [])}


def resolve(providers, key):
    """Pure: key -> provider entry, or None. Rejects anything malformed."""
    if not KEY.match(key or ""):
        return None
    p = providers.get(key)
    if not p or not ID.match(p.get("id", "")):
        return None
    return p


def question(action, p):
    verb = "Ενεργοποίηση" if action == "enable" else "Εγκατάσταση"
    paid = p.get("account") in ("free", "paid") or p.get("access") in ("free_account", "paid")
    note = "\n\nΧρειάζεται λογαριασμό στην υπηρεσία." if paid else ""
    return "{0}: {1}\n\nΤο Kodi θα το κάνει από το επίσημο αποθετήριο.{2}\n\nΝα συνεχίσουμε;".format(
        verb, p.get("display", p["key"]), note)


def main(argv):
    import xbmc
    import xbmcgui
    if len(argv) != 3 or argv[1] not in ("enable", "install"):
        return 2
    here = os.path.dirname(os.path.abspath(__file__))
    p = resolve(load(os.path.join(here, "providers.json")), argv[2])
    if p is None:
        return 2
    if not xbmcgui.Dialog().yesno("BLACKJOHNNY MAX", question(argv[1], p)):
        return 0
    xbmc.executebuiltin("{0}({1})".format("EnableAddon" if argv[1] == "enable" else "InstallAddon", p["id"]))
    return 0


if __name__ == "__main__":
    sys.exit(main(sys.argv))
