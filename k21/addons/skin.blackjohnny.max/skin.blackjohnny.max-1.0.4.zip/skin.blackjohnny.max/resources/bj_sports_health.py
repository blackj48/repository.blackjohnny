# -*- coding: utf-8 -*-
"""BLACKJOHNNY MAX - Sports Source Health (S0). On demand only:

    RunScript(special://skin/resources/bj_sports_health.py)

Measures what this Kodi's PVR can actually give a Sports Center, BEFORE any
sports screen is designed on assumptions.

What it does:
  * asks Kodi, over local JSON-RPC, for PVR clients, channel groups,
    channels and their EPG (the next 48 hours);
  * classifies each broadcast's genre by comparing it with KODI'S OWN genre
    labels (strings 19499-19691, the DVB content codes Kodi translates) -
    never by reading titles;
  * shows the numbers in a text viewer and writes them, numbers only, to
    special://temp/bjmax-sports-health.json so they can be sent back.

What it never does: network access, reading any add-on's settings, logging,
storing or showing titles, channel names, URLs, paths or ids; background
work; changing anything in Kodi.

DVB note: the sports content codes are general, special event, magazine,
football, tennis/squash, TEAM SPORTS, athletics, motor sport, water, winter,
equestrian, martial. There is no basketball code - basketball, volleyball
and handball are all "team sports".
"""
import datetime
import json
import os
import re
import sys

TOOL_VERSION = "2026-09-24.5"
# .5 (Kodi, 24 Sep 23:38): the guide diagnosis showed 927 broadcasts returned
#    and ALL 927 "unreadable time". The times are fine ("YYYY-MM-DD HH:MM:SS",
#    CDateTime::GetAsDBDateTime); datetime.strptime is not: in Kodi's embedded
#    Python it is initialised once per process and then fails with
#    "'NoneType' object is not callable" (Kodi wiki, Python Problems). The
#    time is now parsed with a regular expression - no strptime anywhere.
# .4 (Kodi, 24 Sep 23:26): .3 crashed («Σφάλμα πρόσθετου»). Kodi serialises an
#    EPG tag's genre with CPVREpgInfoTag::Serialize as Genre() - a LIST of
#    strings - although the JSON-RPC schema says string; .3 called .strip()
#    on it. classify() now takes a string or a list. And the script can no
#    longer die silently: any exception is reported (class + stage only) as
#    SCRIPT_ERROR, with the counts gathered so far.
# .3 (Kodi, 24 Sep 23:12): 85 channels, 10 with now/next, yet 0 broadcasts in
#    the window. Something between PVR.GetBroadcasts and the window drops them;
#    the report now shows each stage (returned / unreadable time / ended /
#    beyond the window / in the window, hours of the first and last tag
#    relative to now), and the now/next genres as a second, independent source.
#    Verdicts EPG_NOT_READABLE / EPG_TIME_MISMATCH instead of a false NO_EPG.
# .2 (Kodi, 24 Sep 22:47): the demo PVR client was enabled, yet the report said 0.
#    Kodi 21's JSON-RPC schema knows the add-on type only by its current name
#    "kodi.pvrclient" (AddonInfo.cpp); "xbmc.pvrclient" is accepted in addon.xml
#    but REJECTED as a JSON-RPC parameter, and the error was read as "none".
#    Now: the current type name; every failed call is counted and reported as
#    an error (RPC_ERROR), never as zero; no step depends on another's count.
WINDOW_HOURS = 48
REPORT = "special://temp/bjmax-sports-health.json"
SPORTS_FIRST, SPORTS_LAST = 19548, 19559          # Kodi: CPVREpg::ConvertGenreIdToString
GENRE_FIRST, GENRE_LAST = 19499, 19691
SUB = ("general", "special_event", "magazine", "football", "tennis", "team_sports",
       "athletics", "motor_sport", "water", "winter", "equestrian", "martial")
IDENTIFIED = set(range(3, 12))                  # names a sport, not just "sports"
SPORTS_GROUP_LABELS = {"αθλητικά", "αθλητικα", "sports", "sport"}   # the user's own group
SEP = " / "                                      # Kodi's default video item separator


def _classify_one(g, sports_labels, dvb_labels):
    order = sorted(range(len(sports_labels)), key=lambda i: -len(sports_labels[i]))
    for i in order:
        lab = sports_labels[i]
        if lab and (g == lab or g.startswith(lab + SEP) or g.endswith(SEP + lab) or (SEP + lab + SEP) in g):
            return "sports", i
    for lab in dvb_labels:
        if lab and (g == lab or g.startswith(lab + SEP) or g.endswith(SEP + lab)):
            return "dvb_other", None
    return "text", None


def classify(genre, sports_labels, dvb_labels):
    """-> ('none'|'text'|'dvb_other'|'sports', sub_index or None).
    genre: a string OR a list of strings (Kodi sends a list). sports_labels:
    the 12 localized labels (index = DVB sub-type). Sports wins over other
    DVB genres, which win over free text; among sports the most specific."""
    tokens = genre if isinstance(genre, (list, tuple)) else [genre]
    tokens = [t.strip() for t in tokens if isinstance(t, str) and t.strip()]
    if not tokens:
        return "none", None
    results = [_classify_one(t, sports_labels, dvb_labels) for t in tokens]
    sports = [r for r in results if r[0] == "sports"]
    if sports:
        specific = [r for r in sports if r[1] not in (0, 1, 2)]
        return (specific or sports)[0]
    if any(r[0] == "dvb_other" for r in results):
        return "dvb_other", None
    return "text", None


DB_TIME = re.compile(r"^(\d{4})-(\d\d)-(\d\d)[ T](\d\d):(\d\d):(\d\d)")


def parse_utc(text):
    """Kodi's "YYYY-MM-DD HH:MM:SS" (UTC for PVR data) -> datetime, or None.
    Deliberately not datetime.strptime (broken in Kodi's embedded Python)."""
    m = DB_TIME.match(text) if isinstance(text, str) else None
    if not m:
        return None
    try:
        return datetime.datetime(*(int(g) for g in m.groups()))
    except ValueError:
        return None


def new_counts():
    return {"stage": "start", "script_error": None,
            "clients": 0, "demo": False, "pvr_available": False, "groups": 0, "sports_group": False,
         "channels": 0, "channels_nownext": 0, "channels_with_epg": 0, "broadcasts": 0,
         "genre_none": 0, "genre_text": 0, "genre_dvb_other": 0, "sports": 0, "sports_live_now": 0,
         "sports_channels": 0, "by_sub": {k: 0 for k in SUB}, "reminders": 0, "recordings": 0,
         "cancelled": False, "rpc_errors": 0,
         "epg_returned": 0, "epg_unreadable_time": 0, "epg_ended": 0, "epg_beyond": 0,
         "epg_first_h": None, "epg_last_h": None,
         "nownext_items": 0, "nownext_with_genre": 0, "nownext_sports": 0}


def collect(rpc, now, sports_labels, dvb_labels, demo_ids=(), progress=None, d=None):
    """rpc(method, params) -> result dict. Pure apart from rpc and progress.
    Fills d (new_counts()) in place, stage by stage, so a crash keeps what
    was gathered."""
    d = new_counts() if d is None else d

    def call(method, params):
        res = rpc(method, params)
        if res is None:                   # Kodi answered with an error, not with "nothing"
            d["rpc_errors"] += 1
            return {}
        return res
    d["stage"] = "addons"
    addons = call("Addons.GetAddons", {"type": "kodi.pvrclient", "enabled": True}).get("addons") or []
    ids = [a.get("addonid", "") for a in addons]
    d["clients"] = len(ids)
    d["demo"] = any(i in demo_ids for i in ids)
    props = call("PVR.GetProperties", {"properties": ["available"]})
    d["pvr_available"] = bool(props.get("available"))
    if not d["pvr_available"]:
        return d
    d["stage"] = "channels"
    groups = call("PVR.GetChannelGroups", {"channeltype": "tv"}).get("channelgroups") or []
    d["groups"] = len(groups)
    d["sports_group"] = any((g.get("label") or "").strip().lower() in SPORTS_GROUP_LABELS for g in groups)
    chans = call("PVR.GetChannels", {"channelgroupid": "alltv",
                                     "properties": ["hidden", "broadcastnow", "broadcastnext"]}).get("channels") or []
    chans = [c for c in chans if not c.get("hidden")]
    d["channels"] = len(chans)
    end = now + datetime.timedelta(hours=WINDOW_HOURS)
    d["stage"] = "guide"
    for n, c in enumerate(chans):
        if progress and progress(n, len(chans)):
            d["cancelled"] = True
            break
        if c.get("broadcastnow") or c.get("broadcastnext"):
            d["channels_nownext"] += 1
        for nn in (c.get("broadcastnow"), c.get("broadcastnext")):
            if nn:
                d["nownext_items"] += 1
                if classify(nn.get("genre"), sports_labels, dvb_labels)[0] != "none":
                    d["nownext_with_genre"] += 1
                if classify(nn.get("genre"), sports_labels, dvb_labels)[0] == "sports":
                    d["nownext_sports"] += 1
        res = call("PVR.GetBroadcasts", {"channelid": c.get("channelid"),
                                         "properties": ["genre", "starttime", "endtime", "isactive"]})
        seen, sports_here = 0, 0
        for b in res.get("broadcasts") or []:
            d["epg_returned"] += 1
            st, en = parse_utc(b.get("starttime")), parse_utc(b.get("endtime"))
            if st is None or en is None:
                d["epg_unreadable_time"] += 1
                continue
            fh = int((st - now).total_seconds() // 3600)
            lh = int((en - now).total_seconds() // 3600)
            d["epg_first_h"] = fh if d["epg_first_h"] is None else min(d["epg_first_h"], fh)
            d["epg_last_h"] = lh if d["epg_last_h"] is None else max(d["epg_last_h"], lh)
            if en <= now:
                d["epg_ended"] += 1
                continue
            if st >= end:
                d["epg_beyond"] += 1
                continue
            seen += 1
            kind, sub = classify(b.get("genre"), sports_labels, dvb_labels)
            d["genre_" + kind if kind != "sports" else "sports"] += 1
            if kind == "sports":
                sports_here += 1
                d["by_sub"][SUB[sub]] += 1
                if b.get("isactive"):
                    d["sports_live_now"] += 1
        d["broadcasts"] += seen
        if seen:
            d["channels_with_epg"] += 1
        if sports_here:
            d["sports_channels"] += 1
    d["stage"] = "timers"
    timers = call("PVR.GetTimers", {"properties": ["isreminder"]}).get("timers") or []
    d["reminders"] = sum(1 for t in timers if t.get("isreminder"))
    recs = call("PVR.GetRecordings", {"limits": {"start": 0, "end": 1}})
    d["recordings"] = int((recs.get("limits") or {}).get("total") or 0)
    d["stage"] = "done"
    return d


def pct(a, b):
    return round(100.0 * a / b, 1) if b else 0.0


def verdict(d):
    """-> (quality, suggested UI tier) - the Adaptive Sports UI input.
    An error is never read as "nothing": SCRIPT_ERROR and RPC_ERROR outrank
    every count."""
    if d["script_error"]:
        return "SCRIPT_ERROR", "addons"
    if d["rpc_errors"]:
        return "RPC_ERROR", "addons"
    if not d["clients"] or not d["pvr_available"]:
        return "NO_PVR", "addons"
    if not d["channels"]:
        return "NO_CHANNELS", "addons"
    if not d["channels_with_epg"]:
        if d["epg_returned"]:
            return "EPG_TIME_MISMATCH", "channels"     # tags exist, none fall in the window
        if d["nownext_items"]:
            return "EPG_NOT_READABLE", "channels"      # now/next exist, the full guide came back empty
        return "NO_EPG", "channels"
    if not d["sports"]:
        return "NO_SPORTS_GENRE", "channels"
    identified = sum(d["by_sub"][SUB[i]] for i in IDENTIFIED)
    if pct(identified, d["sports"]) >= 50.0:
        return "GOOD", "by_sport"
    return "PARTIAL", "live_today"


def summary(d, when):
    q, tier = verdict(d)
    identified = sum(d["by_sub"][SUB[i]] for i in IDENTIFIED)
    return {"tool": "bj_sports_health", "version": TOOL_VERSION, "when_utc": when,
            "window_hours": WINDOW_HOURS, "demo_data": d["demo"], "cancelled": d["cancelled"],
            "rpc_errors": d["rpc_errors"], "script_error": d["script_error"], "stage": d["stage"],
            "pvr": {"clients_enabled": d["clients"], "available": d["pvr_available"], "tv_groups": d["groups"],
                    "tv_channels": d["channels"], "channels_with_nownext": d["channels_nownext"],
                    "channels_with_epg": d["channels_with_epg"],
                    "epg_coverage_pct": pct(d["channels_with_epg"], d["channels"]),
                    "broadcasts_in_window": d["broadcasts"]},
            "epg_diag": {"returned": d["epg_returned"], "unreadable_time": d["epg_unreadable_time"],
                         "ended_before_now": d["epg_ended"], "beyond_window": d["epg_beyond"],
                         "in_window": d["broadcasts"], "first_start_h": d["epg_first_h"],
                         "last_end_h": d["epg_last_h"], "nownext_items": d["nownext_items"],
                         "nownext_with_genre": d["nownext_with_genre"], "nownext_sports": d["nownext_sports"]},
            "genres": {"dvb_sports": d["sports"], "dvb_other": d["genre_dvb_other"],
                       "text_not_dvb": d["genre_text"], "none": d["genre_none"]},
            "sports": {"broadcasts": d["sports"], "live_now": d["sports_live_now"],
                       "channels_with_sports": d["sports_channels"], "sports_group": d["sports_group"],
                       "subgenre_coverage_pct": pct(identified, d["sports"]), "by_subgenre": dict(d["by_sub"])},
            "features": {"reminders_set": d["reminders"], "recordings": d["recordings"]},
            "quality": q, "suggested_tier": tier}


QUALITY_TEXT = {
    "SCRIPT_ERROR": "ΣΦΑΛΜΑ ΤΟΥ ΕΡΓΑΛΕΙΟΥ - η μέτρηση σταμάτησε, τα νούμερα είναι μερικά",
    "RPC_ERROR": "ΣΦΑΛΜΑ: το Kodi απέρριψε ερώτημα - τα νούμερα δεν είναι αξιόπιστα",
    "NO_PVR": "Δεν υπάρχει ενεργό πρόσθετο PVR",
    "NO_CHANNELS": "Το PVR δεν έχει κανάλια",
    "NO_EPG": "Τα κανάλια δεν έχουν πρόγραμμα",
    "EPG_NOT_READABLE": "Υπάρχει τώρα/επόμενο, αλλά το πλήρες πρόγραμμα ήρθε άδειο",
    "EPG_TIME_MISMATCH": "Υπάρχει πρόγραμμα, αλλά καμία εκπομπή μέσα στο διάστημα",
    "NO_SPORTS_GENRE": "Το πρόγραμμα δεν σημειώνει αθλητικά (κωδικός DVB)",
    "PARTIAL": "Αθλητικά ναι, υποκατηγορίες λίγες",
    "GOOD": "Αθλητικά με υποκατηγορίες",
}
TIER_TEXT = {"by_sport": "ανά άθλημα", "live_today": "Ζωντανά / Σήμερα / Αύριο / Κανάλια",
             "channels": "μόνο αθλητικά κανάλια", "addons": "μόνο επίσημα πρόσθετα"}


def text_report(s):
    """Verdict first (D59); «Όνομα: τιμή» lines, no space padding (D58)."""
    yn = lambda v: "ΝΑΙ" if v else "ΟΧΙ"
    p, g, sp, f = s["pvr"], s["genres"], s["sports"], s["features"]
    e = s["epg_diag"]
    b = sp["by_subgenre"]
    L = ["ΑΠΟΤΕΛΕΣΜΑ: %s (%s)" % (QUALITY_TEXT[s["quality"]], s["quality"]),
         "Προτεινόμενη οθόνη: %s" % TIER_TEXT[s["suggested_tier"]]]
    if s["demo_data"]:
        L.append("ΔΟΚΙΜΑΣΤΙΚΑ ΔΕΔΟΜΕΝΑ (DEMO) - όχι πραγματικό πρόγραμμα")
    if s["cancelled"]:
        L.append("Η μέτρηση διακόπηκε - τα νούμερα είναι μερικά")
    if s["script_error"]:
        L.append("Σφάλμα: %s στο στάδιο «%s»" % (s["script_error"], s["stage"]))
    if s["rpc_errors"]:
        L.append("Ερωτήματα που απέτυχαν: %d" % s["rpc_errors"])
    L += ["Διάστημα: επόμενες %d ώρες · χωρίς δίκτυο" % s["window_hours"], "",
          "PVR",
          "Ενεργά πρόσθετα PVR: %d" % p["clients_enabled"],
          "PVR διαθέσιμο: %s" % yn(p["available"]),
          "Ομάδες καναλιών TV: %d" % p["tv_groups"],
          "Κανάλια TV: %d" % p["tv_channels"],
          "Κανάλια με τώρα/επόμενο: %d" % p["channels_with_nownext"],
          "Κανάλια με πρόγραμμα: %d (%.1f%%)" % (p["channels_with_epg"], p["epg_coverage_pct"]),
          "Εκπομπές στο διάστημα: %d" % p["broadcasts_in_window"], "",
          "ΔΙΑΓΝΩΣΗ ΠΡΟΓΡΑΜΜΑΤΟΣ",
          "Εκπομπές που έδωσε το Kodi: %d" % e["returned"],
          "Χωρίς αναγνώσιμη ώρα: %d · Τελείωσαν: %d · Μετά το διάστημα: %d · Μέσα: %d"
          % (e["unreadable_time"], e["ended_before_now"], e["beyond_window"], e["in_window"]),
          "Πρώτη έναρξη / τελευταία λήξη (ώρες από τώρα): %s / %s"
          % ("-" if e["first_start_h"] is None else e["first_start_h"],
             "-" if e["last_end_h"] is None else e["last_end_h"]),
          "Τώρα/επόμενο: %d · με είδος: %d · αθλητικά: %d"
          % (e["nownext_items"], e["nownext_with_genre"], e["nownext_sports"]), "",
          "ΕΙΔΗ ΠΡΟΓΡΑΜΜΑΤΟΣ",
          "Αθλητικά (κωδικός DVB): %d" % g["dvb_sports"],
          "Άλλα είδη (κωδικός DVB): %d" % g["dvb_other"],
          "Ελεύθερο κείμενο, όχι DVB: %d" % g["text_not_dvb"],
          "Χωρίς είδος: %d" % g["none"], "",
          "ΑΘΛΗΤΙΚΑ",
          "Αθλητικές εκπομπές: %d · ζωντανά τώρα: %d" % (sp["broadcasts"], sp["live_now"]),
          "Κανάλια με αθλητικά: %d" % sp["channels_with_sports"],
          "Ομάδα «Αθλητικά»: %s" % yn(sp["sports_group"]),
          "Κάλυψη υποκατηγορίας: %.1f%%" % sp["subgenre_coverage_pct"],
          "Ποδόσφαιρο: %d · Ομαδικά (μπάσκετ, βόλεϊ...): %d · Τένις: %d · Μηχανοκίνητα: %d"
          % (b["football"], b["team_sports"], b["tennis"], b["motor_sport"]),
          "Άλλα αθλήματα: %d · Χωρίς υποκατηγορία: %d"
          % (sum(b[k] for k in ("athletics", "water", "winter", "equestrian", "martial")),
             sum(b[k] for k in ("general", "special_event", "magazine"))), "",
          "ΛΕΙΤΟΥΡΓΙΕΣ",
          "Υπενθυμίσεις (ορισμένες): %d · Εγγραφές: %d" % (f["reminders_set"], f["recordings"]), "",
          "Η DVB δεν έχει κωδικό «μπάσκετ»: μπαίνει στα «Ομαδικά».",
          "Τα νούμερα γράφτηκαν στο %s (μόνο αριθμοί)." % REPORT]
    return "\n".join(L)


def demo_clients(here):
    try:
        with open(os.path.join(here, "providers.json"), "r", encoding="utf-8") as fh:
            data = json.load(fh)
        return {e.get("id") for e in data.get("dev_only_clients", []) if e.get("id")}
    except (OSError, ValueError):
        return set()


def main(argv):
    import xbmc
    import xbmcgui
    import xbmcvfs

    def rpc(method, params):
        raw = xbmc.executeJSONRPC(json.dumps({"jsonrpc": "2.0", "id": 1, "method": method, "params": params}))
        try:
            return json.loads(raw).get("result")
        except ValueError:
            return None

    sports = [xbmc.getLocalizedString(i) for i in range(SPORTS_FIRST, SPORTS_LAST + 1)]
    dvb = [xbmc.getLocalizedString(i) for i in range(GENRE_FIRST, GENRE_LAST + 1)
           if not SPORTS_FIRST <= i <= SPORTS_LAST]
    bar = xbmcgui.DialogProgress()
    bar.create("BLACKJOHNNY MAX", "Μέτρηση δεδομένων PVR για τα αθλητικά...")

    def progress(n, total):
        bar.update(int(100 * n / max(total, 1)), "Κανάλι %d από %d" % (n + 1, total))
        return bar.iscanceled()
    now = datetime.datetime.utcnow().replace(microsecond=0)
    d = new_counts()
    try:
        collect(rpc, now, sports, dvb, demo_clients(os.path.dirname(os.path.abspath(__file__))), progress, d)
    except Exception as exc:            # reported, never silent; class name only, no message text
        d["script_error"] = type(exc).__name__
    finally:
        bar.close()
    s = summary(d, now.strftime("%Y-%m-%d %H:00"))
    fh = xbmcvfs.File(REPORT, "w")
    try:
        fh.write(json.dumps(s, ensure_ascii=False, indent=2))
    finally:
        fh.close()
    xbmcgui.Dialog().textviewer("Αθλητικά δεδομένα", text_report(s))
    return 0


if __name__ == "__main__":
    sys.exit(main(sys.argv))
