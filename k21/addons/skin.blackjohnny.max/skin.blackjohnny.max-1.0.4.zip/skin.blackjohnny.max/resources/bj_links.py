# -*- coding: utf-8 -*-
"""BLACKJOHNNY MAX - personal web links and Android apps (Sports, SPORTS1E).

    RunScript(special://skin/resources/bj_links.py,<mode>[,<slot>])
      add | once | addapp | browser | item,<1..12>

The build ships EMPTY: no site, no stream, no provider, no suggestion. Every
entry is typed by the user on this device and stored as skin strings
(bj.link.<n>.*) in Kodi's own skin settings - never in the release.

A web link is opened OUTSIDE Kodi, in the system browser:
  Windows   System.Exec("<url>")   -> ShellExecuteEx (WIN32Util.cpp)
  Android   StartAndroidActivity("<browser>","android.intent.action.VIEW","","<url>")
            (Kodi calls setPackage(package), so a browser app must be chosen once)
  elsewhere not offered.
An Android app entry is StartAndroidActivity("<package>").

Because the URL reaches ShellExecute, it is rebuilt from validated parts:
http/https only; a plain host name or IPv4; no user:password@; no spaces,
quotes, backslashes or control characters; no credential-like query keys
(token, key, password, username...); no playlist / stream / media file
(.m3u, .m3u8, .mpd, .ts, ...). Rejected input is never stored or shown.

Never: network access, logging, files, settings of other add-ons, background
work, preloaded entries.
"""
import re
import sys

TOOL_VERSION = "2026-09-25.1"
SLOTS = 12
P = "bj.link."
SEP = ":" + "//"
MAX_URL, MAX_NAME = 2048, 40
BAD_CHARS = re.compile(r'[\s"\\<>`^{}|\x00-\x1f\x7f]')
LABEL = re.compile(r"^(?!-)[a-z0-9-]{1,63}(?<!-)$")
IPV4 = re.compile(r"^(25[0-5]|2[0-4]\d|1?\d?\d)(\.(25[0-5]|2[0-4]\d|1?\d?\d)){3}$")
PACKAGE = re.compile(r"^[a-zA-Z][a-zA-Z0-9_]*(\.[a-zA-Z][a-zA-Z0-9_]*)+$")
SECRET_KEYS = {"token", "access_token", "auth", "authorization", "key", "apikey", "api_key", "password",
               "pass", "passwd", "pwd", "username", "user", "login", "sig", "signature", "secret",
               "session", "sessionid", "sid", "hash", "hmac", "jwt"}
MEDIA_EXT = (".m3u", ".m3u8", ".mpd", ".ts", ".mp4", ".mkv", ".avi", ".flv", ".mov", ".webm", ".aac",
             ".mp3", ".xspf", ".pls", ".strm", ".xml", ".gz", ".torrent", ".acelive")

T = {  # the user's language; one place
    "menu": "Web σύνδεσμοι", "name": "Όνομα", "url": "Διεύθυνση (https://...)",
    "pkg": "Όνομα πακέτου Android (π.χ. com.example.app)", "open": "Άνοιγμα", "edit": "Επεξεργασία",
    "delete": "Διαγραφή", "del_q": "Διαγραφή του «%s»;", "full": "Υπάρχουν ήδη 12 σύνδεσμοι. Διάγραψε έναν πρώτα.",
    "saved": "Αποθηκεύτηκε · μόνο σε αυτή τη συσκευή", "unsupported": "Σε αυτή τη συσκευή δεν ανοίγουν εξωτερικές εφαρμογές.",
    "no_browser": "Διάλεξε πρώτα browser για Android («Browser για Android»).",
    "browser": "Browser για Android (όνομα πακέτου)",
    "scheme": "Μόνο διευθύνσεις http:// ή https://.", "userinfo": "Η διεύθυνση περιέχει όνομα χρήστη ή κωδικό. Δεν αποθηκεύεται.",
    "secret": "Η διεύθυνση περιέχει κλειδί, κωδικό ή token. Δεν αποθηκεύεται.",
    "media": "Αυτή είναι λίστα ή ροή, όχι σελίδα. Εδώ μπαίνουν μόνο σελίδες.",
    "chars": "Η διεύθυνση έχει μη επιτρεπτούς χαρακτήρες (κενά, εισαγωγικά κ.λπ.).",
    "host": "Μη έγκυρο όνομα διακομιστή.", "long": "Η διεύθυνση είναι πολύ μεγάλη.",
    "badname": "Το όνομα θέλει 1-40 χαρακτήρες, χωρίς εισαγωγικά ή \\.",
    "badpkg": "Μη έγκυρο όνομα πακέτου (π.χ. com.example.app).",
}


def check_url(text):
    """-> (normalised url, None) or (None, reason key). Pure."""
    s = (text or "").strip()
    if not s:
        return None, "scheme"
    if len(s) > MAX_URL:
        return None, "long"
    if BAD_CHARS.search(s):
        return None, "chars"
    if SEP not in s:
        return None, "scheme"
    scheme, rest = s.split(SEP, 1)
    scheme = scheme.lower()
    if scheme not in ("http", "https"):
        return None, "scheme"
    cut = min([i for i in (rest.find("/"), rest.find("?"), rest.find("#")) if i >= 0] or [len(rest)])
    authority, tail = rest[:cut], rest[cut:]
    if "@" in authority:
        return None, "userinfo"
    host, port = authority, ""
    if ":" in authority:
        host, port = authority.rsplit(":", 1)
        if not port.isdigit() or not 0 < int(port) < 65536:
            return None, "host"
    host = host.lower().rstrip(".")
    labels = host.split(".")
    if not (IPV4.match(host) or (len(labels) >= 2 and all(LABEL.match(l) for l in labels)
                                 and not labels[-1].isdigit())):
        return None, "host"
    path = tail.split("#", 1)[0]
    path, _, query = path.partition("?")
    if path.lower().rstrip("/").endswith(MEDIA_EXT):
        return None, "media"
    for part in query.split("&"):
        k = part.split("=", 1)[0].strip().lower()
        if k in SECRET_KEYS:
            return None, "secret"
    return "%s%s%s%s%s" % (scheme, SEP, host, (":" + port) if port else "", tail), None


def host_of(url):
    rest = url.split(SEP, 1)[1]
    return re.split(r"[/?#]", rest, 1)[0]


def check_name(text):
    s = (text or "").strip()
    return s if 0 < len(s) <= MAX_NAME and not re.search(r'["\\\x00-\x1f\x7f]', s) else None


def check_package(text):
    s = (text or "").strip()
    return s if len(s) <= 150 and PACKAGE.match(s) else None


class Store(object):
    """The 12 slots as skin strings; get(key) / put(key, value) / clear(key) injected."""
    FIELDS = ("kind", "name", "target", "host")

    def __init__(self, get, put, clear):
        self.get, self.put, self.clear = get, put, clear

    def rows(self):
        out = []
        for n in range(1, SLOTS + 1):
            r = {f: self.get("%s%d.%s" % (P, n, f)) for f in self.FIELDS}
            if r["kind"] in ("web", "app") and r["name"] and r["target"]:
                out.append(r)
        return out

    def write(self, rows):
        """Rewrite every slot: entries first, in order, the rest cleared (no holes)."""
        for n in range(1, SLOTS + 1):
            r = rows[n - 1] if n <= len(rows) else None
            for f in self.FIELDS:
                key = "%s%d.%s" % (P, n, f)
                if r and r.get(f):
                    self.put(key, r[f])
                else:
                    self.clear(key)


def open_command(kind, target, platform, browser):
    """-> builtin string or None (not possible here). target is already validated."""
    if kind == "app":
        return 'StartAndroidActivity("%s")' % target if platform == "android" else None
    if platform == "windows":
        return 'System.Exec("%s")' % target
    if platform == "android" and browser:
        return 'StartAndroidActivity("%s","android.intent.action.VIEW","","%s")' % (browser, target)
    return None


def run(argv, ui, store, platform, execute):
    """ui: input(heading, default) -> str, select(heading, items) -> index, yesno(text) -> bool,
    say(text). Pure apart from the injected callables."""
    mode = argv[1] if len(argv) > 1 else ""
    browser = check_package(store.get(P + "browser"))

    def ask_web(name="", url=""):
        name = check_name(ui.input(T["name"], name))
        if not name:
            ui.say(T["badname"])
            return None
        target, why = check_url(ui.input(T["url"], url))
        if not target:
            ui.say(T[why])
            return None
        return {"kind": "web", "name": name, "target": target, "host": host_of(target)}

    def ask_app(name="", pkg=""):
        name = check_name(ui.input(T["name"], name))
        if not name:
            ui.say(T["badname"])
            return None
        target = check_package(ui.input(T["pkg"], pkg))
        if not target:
            ui.say(T["badpkg"])
            return None
        return {"kind": "app", "name": name, "target": target, "host": target}

    def launch(kind, target):
        cmd = open_command(kind, target, platform, browser)
        if cmd:
            execute(cmd)
        else:
            ui.say(T["no_browser"] if platform == "android" and kind == "web" else T["unsupported"])

    rows = store.rows()
    if mode in ("add", "addapp"):
        if mode == "addapp" and platform != "android":
            ui.say(T["unsupported"])
            return 0
        if len(rows) >= SLOTS:
            ui.say(T["full"])
            return 0
        r = ask_web() if mode == "add" else ask_app()
        if r:
            store.write(rows + [r])
            ui.say(T["saved"])
    elif mode == "once":
        target, why = check_url(ui.input(T["url"], ""))
        if target:
            launch("web", target)
        else:
            ui.say(T[why])
    elif mode == "browser":
        if platform != "android":
            ui.say(T["unsupported"])
            return 0
        pkg = check_package(ui.input(T["browser"], browser or ""))
        if pkg:
            store.put(P + "browser", pkg)
            ui.say(T["saved"])
        else:
            ui.say(T["badpkg"])
    elif mode == "item" and len(argv) > 2 and argv[2].isdigit() and 1 <= int(argv[2]) <= len(rows):
        i = int(argv[2]) - 1
        r = rows[i]
        choice = ui.select(r["name"], [T["open"], T["edit"], T["delete"]])
        if choice == 0:
            launch(r["kind"], r["target"])
        elif choice == 1:
            new = ask_web(r["name"], r["target"]) if r["kind"] == "web" else ask_app(r["name"], r["target"])
            if new:
                rows[i] = new
                store.write(rows)
                ui.say(T["saved"])
        elif choice == 2 and ui.yesno(T["del_q"] % r["name"]):
            store.write(rows[:i] + rows[i + 1:])
    return 0


def main(argv):
    import xbmc
    import xbmcgui

    def esc(v):
        return v.replace("\\", "\\\\").replace('"', '\\"')     # validated values contain neither

    store = Store(lambda k: xbmc.getInfoLabel("Skin.String(%s)" % k),
                  lambda k, v: xbmc.executebuiltin('Skin.SetString(%s,"%s")' % (k, esc(v))),
                  lambda k: xbmc.executebuiltin("Skin.Reset(%s)" % k))
    dialog = xbmcgui.Dialog()

    class UI(object):
        def input(self, heading, default):
            return dialog.input(heading, defaultt=default or "")

        def select(self, heading, items):
            return dialog.select(heading, items)

        def yesno(self, text):
            return dialog.yesno(T["menu"], text)

        def say(self, text):
            dialog.notification(T["menu"], text, xbmcgui.NOTIFICATION_INFO, 5000)

    platform = ("windows" if xbmc.getCondVisibility("System.Platform.Windows") else
                "android" if xbmc.getCondVisibility("System.Platform.Android") else "other")
    return run(argv, UI(), store, platform, xbmc.executebuiltin)


if __name__ == "__main__":
    sys.exit(main(sys.argv))
