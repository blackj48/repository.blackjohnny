from __future__ import annotations

from datetime import datetime, timezone
from typing import Any, Dict, List
from urllib.parse import urlsplit

from .jsonrpc import KodiJsonRpc
from .sourceprobe import identity
from .redact import redact


def _utc_now() -> str:
    return datetime.now(timezone.utc).isoformat()


def _protocol(path: str) -> str:
    value = (path or "").strip()

    if not value:
        return "unknown"

    if len(value) >= 3 and value[1:3] in (":\\", ":/"):
        return "local"

    if value.lower().startswith("special://"):
        return "special"

    parsed = urlsplit(value)
    if parsed.scheme:
        return parsed.scheme.lower()

    return "other"


class SourceHub:
    MEDIA_TYPES = ("video", "music", "pictures", "files", "programs")

    def __init__(self, rpc: KodiJsonRpc) -> None:
        self._rpc = rpc
        # Probe targets carry the path; published items never do. Keeping the
        # two apart here is what stops a path reaching runtime_state.json.
        self._targets: List[Dict[str, str]] = []

    def collect(self) -> Dict[str, Any]:
        items: List[Dict[str, str]] = []
        targets: List[Dict[str, str]] = []
        by_media: Dict[str, int] = {}
        errors: Dict[str, str] = {}

        for media in self.MEDIA_TYPES:
            try:
                result = self._rpc.call(
                    "Files.GetSources",
                    {"media": media},
                ) or {}

                sources = result.get("sources") or []
                by_media[media] = len(sources)

                for source in sources:
                    # Keep labels, protocol and the identity hash. Raw paths are
                    # never persisted or logged because they may contain
                    # credentials; they go into the target list instead, which
                    # stays inside the service.
                    path = str(source.get("file") or "")
                    ident = identity(media, path)
                    items.append({
                        "media": media,
                        "label": str(source.get("label") or ""),
                        "protocol": _protocol(path),
                        "identity": ident,
                    })
                    targets.append({
                        "identity": ident,
                        "media": media,
                        "path": path,
                    })
            except Exception as exc:
                by_media[media] = 0
                # redacted, not raw: this value is persisted to
                # runtime_state.json, and a Kodi source error carries the
                # path - credentials included - in its message.
                errors[media] = redact(str(exc))

        self._targets = targets

        return {
            "updated_at": _utc_now(),
            "total": len(items),
            "by_media": by_media,
            "items": items,
            "errors": errors,
        }

    def last_targets(self) -> List[Dict[str, str]]:
        """Probe targets from the last collect. Carries paths - service only.

        A copy, so a caller cannot mutate the list the next collect replaces.
        """
        return list(self._targets)
