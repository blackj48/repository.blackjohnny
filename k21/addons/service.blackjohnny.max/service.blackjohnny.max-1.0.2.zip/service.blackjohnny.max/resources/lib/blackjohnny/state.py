from __future__ import annotations

import copy
import json
import os
import time
import uuid
from datetime import datetime, timezone
from typing import Any, Dict

import xbmcgui
import xbmcvfs

from . import config, log
from . import sourcecontract
from .redact import redact


def _utc_now() -> str:
    return datetime.now(timezone.utc).isoformat()


def _version_string(payload: Dict[str, Any]) -> str:
    version = (
        payload.get("kodi", {})
        .get("application", {})
        .get("version", {})
    )

    if not isinstance(version, dict):
        return ""

    major = version.get("major")
    minor = version.get("minor")
    tag = version.get("tag") or ""
    revision = version.get("revision") or ""

    if major is None:
        return ""

    text = str(major)
    if minor is not None:
        text += "." + str(minor)

    if tag:
        text += " " + str(tag)

    if revision:
        text += " (" + str(revision) + ")"

    return text


class StateStore:
    def __init__(self, addon) -> None:
        self._addon = addon
        self.instance_id = str(uuid.uuid4())
        self._started_monotonic = time.monotonic()
        # None, not 0.0: monotonic() is uptime-based, so on a freshly booted
        # box 0.0 would be within the checkpoint window and the very first
        # state file would never be written.
        self._last_checkpoint = None

        profile_dir = xbmcvfs.translatePath(
            f"special://profile/addon_data/{config.ADDON_ID}/"
        )
        os.makedirs(profile_dir, exist_ok=True)

        self.path = os.path.join(profile_dir, config.STATE_FILENAME)
        self._window = xbmcgui.Window(10000)
        # Set by the orchestrator once the prober exists. None until then, and
        # None is a working state: the Source Hub renders UNKNOWN, which is the
        # truth before anything has been probed.
        self._source_health = None

        self._state: Dict[str, Any] = {
            "schema": 2,
            "service": {
                "id": config.ADDON_ID,
                "version": addon.getAddonInfo("version"),
                "instance_id": self.instance_id,
                "status": "starting",
                "ready": False,
                "started_at": _utc_now(),
                "uptime_seconds": 0,
                "heartbeat_at": None,
                "stopped_at": None,
                "last_error": None,
            },
            "health": {
                "ok": False,
                "updated_at": None,
                "jsonrpc": False,
                "kodi": {},
                "active_players": 0,
            },
            "sources": {
                "updated_at": None,
                "total": 0,
                "by_media": {},
                "items": [],
                "errors": {},
            },
            "ui_bridge": {
                "contract": config.HEALTH_CONTRACT,
            },
        }

    def set_source_health_provider(self, provider) -> None:
        """provider() -> (identity -> {state, detail, checked_at}, stalled).

        Injected rather than imported so that state.py keeps knowing nothing
        about probing, and so the service still starts if the prober does not.
        """
        self._source_health = provider

    def snapshot(self) -> Dict[str, Any]:
        return copy.deepcopy(self._state)

    def set_service_status(
        self,
        status: str,
        ready: bool,
        error: str | None = None,
    ) -> None:
        service = self._state["service"]
        service["status"] = status
        service["ready"] = bool(ready)
        service["last_error"] = redact(error)
        service["uptime_seconds"] = int(
            max(0.0, time.monotonic() - self._started_monotonic)
        )

        if status == "stopped":
            service["stopped_at"] = _utc_now()

        # A status transition is exactly what must be on disk after a crash.
        self.publish(force=True)

    def heartbeat(self) -> None:
        service = self._state["service"]
        service["heartbeat_at"] = _utc_now()
        service["uptime_seconds"] = int(
            max(0.0, time.monotonic() - self._started_monotonic)
        )
        self.publish()

    def update_health(self, payload: Dict[str, Any]) -> None:
        self._state["health"] = payload
        self.publish()

    def update_sources(self, payload: Dict[str, Any]) -> None:
        self._state["sources"] = payload
        self.publish()

    def publish(self, force: bool = False) -> None:
        """Publish to the UI always; persist to disk on a checkpoint.

        Window properties are in-memory and cost nothing, so the skin keeps its
        5 s cadence. runtime_state.json is a real file: writing it on every
        heartbeat meant an fsync and a rename roughly 24,500 times a day for
        data nothing read in between. It is now written at most once per
        config.CHECKPOINT_SECONDS - except for the transitions that must
        survive a crash, which pass force=True.
        """
        self._publish_window_properties()
        self._checkpoint(force=force)

    def _checkpoint(self, force: bool = False) -> None:
        now = time.monotonic()
        if (not force
                and self._last_checkpoint is not None
                and (now - self._last_checkpoint) < config.CHECKPOINT_SECONDS):
            return
        self._last_checkpoint = now
        self._write_json()

    def _health_state(self) -> str:
        service = self._state["service"]
        health = self._state["health"]
        sources = self._state["sources"]

        if not service.get("ready"):
            if service.get("status") == "error":
                return "offline"
            return "starting"

        if not health.get("ok") or not health.get("jsonrpc"):
            return "offline"

        source_errors = sources.get("errors") or {}
        if source_errors:
            return "degraded"

        return "healthy"

    def _publish_window_properties(self) -> None:
        service = self._state["service"]
        health = self._state["health"]
        sources = self._state["sources"]

        source_errors = sources.get("errors") or {}
        health_state = self._health_state()

        # BJMAX PHASE2C SOURCE HUB PUBLISH START
        # Read at publish time, not at collect time: probes finish between
        # source refreshes and this runs on every heartbeat, so the column
        # follows the probes rather than the 60 s collect. A provider that
        # raises is contained - registration is certified under 2C and does
        # not depend on reachability.
        probe_health: Dict[str, Any] = {}
        probe_stalled = 0
        if self._source_health is not None:
            try:
                probe_health, probe_stalled = self._source_health()
            except Exception as exc:
                log.warning(f"Source health provider failed: {redact(str(exc))}")
                probe_health, probe_stalled = {}, 0

        source_contract_summary = sourcecontract.publish(
            self._window, sources, probe_health, probe_stalled)
        # BJMAX PHASE2C SOURCE HUB PUBLISH END

        self._window.setProperty(
            config.PROP_READY,
            "1" if service.get("ready") else "0",
        )
        self._window.setProperty(
            config.PROP_STATUS,
            str(service.get("status") or ""),
        )
        self._window.setProperty(
            config.PROP_VERSION,
            str(service.get("version") or ""),
        )
        self._window.setProperty(
            config.PROP_INSTANCE,
            str(service.get("instance_id") or ""),
        )
        self._window.setProperty(
            config.PROP_UPTIME,
            str(service.get("uptime_seconds", 0)),
        )
        self._window.setProperty(
            config.PROP_HEARTBEAT,
            str(service.get("heartbeat_at") or ""),
        )

        self._window.setProperty(
            config.PROP_HEALTH,
            "1" if health.get("ok") else "0",
        )
        self._window.setProperty(
            config.PROP_HEALTH_STATE,
            health_state,
        )
        self._window.setProperty(
            config.PROP_HEALTH_JSONRPC,
            "1" if health.get("jsonrpc") else "0",
        )
        self._window.setProperty(
            config.PROP_HEALTH_KODI_VERSION,
            _version_string(health),
        )
        self._window.setProperty(
            config.PROP_HEALTH_ACTIVE_PLAYERS,
            str(health.get("active_players", 0)),
        )
        self._window.setProperty(
            config.PROP_HEALTH_SOURCE_ERRORS,
            str(len(source_errors)),
        )
        self._window.setProperty(
            config.PROP_HEALTH_LAST_CHECK,
            str(health.get("updated_at") or ""),
        )
        self._window.setProperty(
            config.PROP_HEALTH_CONTRACT,
            config.HEALTH_CONTRACT,
        )

        # Sources.Total and Sources.Errors are NOT written here. sourcecontract
        # is the single owner of every BJMAX.Sources.* key and already published
        # them above; writing them again made the value depend on statement
        # order inside this one function. Both numbers stay in
        # runtime_state.json below, where they are state rather than contract.

        self._state["ui_bridge"] = {
            "contract": config.HEALTH_CONTRACT,
            "health_state": health_state,
            "source_errors": len(source_errors),
            "kodi_version": _version_string(health),
            "source_contract": sourcecontract.CONTRACT,
            "source_summary": source_contract_summary,
        }

    def _write_json(self) -> None:
        tmp = self.path + ".tmp"
        payload = json.dumps(
            self._state,
            ensure_ascii=False,
            indent=2,
            sort_keys=True,
        )

        try:
            with open(tmp, "w", encoding="utf-8", newline="\n") as handle:
                handle.write(payload)
                handle.write("\n")
                handle.flush()
                os.fsync(handle.fileno())

            os.replace(tmp, self.path)
        except Exception as exc:
            try:
                if os.path.exists(tmp):
                    os.remove(tmp)
            except Exception:
                pass
            log.error(f"Unable to persist runtime state: {redact(str(exc))}")