from __future__ import annotations

import time
from typing import Optional

from . import config, log
from .health import HealthCenter
from .jsonrpc import KodiJsonRpc
from .sourceprobe import Prober
from .sourcehub import SourceHub
from .state import StateStore
from .redact import redact


class Orchestrator:
    def __init__(self, addon, monitor) -> None:
        self._addon = addon
        self._monitor = monitor

        self._rpc = KodiJsonRpc()
        self._state = StateStore(addon)
        self._health = HealthCenter(self._rpc)
        self._sources = SourceHub(self._rpc)
        self._prober = Prober(logger=log)
        self._state.set_source_health_provider(self._source_health)

        self._started = False
        self._stopped = False

        self._next_heartbeat = 0.0
        self._next_health = 0.0
        self._next_sources = 0.0

    def start(self) -> None:
        if self._started:
            return

        self._started = True
        self._stopped = False

        log.info(
            "Starting core service "
            f"v{self._addon.getAddonInfo('version')} "
            f"instance={self._state.instance_id}"
        )

        self._state.set_service_status("starting", ready=False)

        now = time.monotonic()
        self._next_heartbeat = now
        self._next_health = now
        self._next_sources = now

        # Immediate first collection establishes a usable baseline.
        self.tick(force=True)
        self._state.set_service_status("running", ready=True)

        log.info("Core service ready")

    def tick(self, force: bool = False) -> None:
        if not self._started or self._stopped:
            return

        now = time.monotonic()

        if force or now >= self._next_health:
            self._refresh_health()
            self._next_health = now + config.HEALTH_REFRESH_SECONDS

        if force or now >= self._next_sources:
            self._refresh_sources()
            self._next_sources = now + config.SOURCE_REFRESH_SECONDS

        if force or now >= self._next_heartbeat:
            self._state.heartbeat()
            self._next_heartbeat = now + config.HEARTBEAT_SECONDS

    def _refresh_health(self) -> None:
        try:
            payload = self._health.collect()
            self._state.update_health(payload)
        except Exception as exc:
            log.warning(f"Health refresh failed: {redact(str(exc))}")
            payload = self._state.snapshot().get("health", {})
            payload["ok"] = False
            payload["jsonrpc"] = False
            payload["last_error"] = redact(str(exc))
            self._state.update_health(payload)

    def _source_health(self):
        """(identity -> {state, detail, checked_at}, stalled).

        Built from the last targets, so a source the user removed simply stops
        being asked about and its result never matches again. Identity is the
        key throughout: slot N is a rendering position that can point at a
        different source after a reorder, and a late result keyed by N would
        land on the wrong row.
        """
        health = {}
        for target in self._sources.last_targets():
            ident = target.get("identity") or ""
            if ident:
                health[ident] = self._prober.result_for(ident).as_dict()
        return health, self._prober.stalled

    def _refresh_sources(self) -> None:
        try:
            payload = self._sources.collect()
            self._state.update_sources(payload)
        except Exception as exc:
            log.warning(f"Source Hub refresh failed: {redact(str(exc))}")
            payload = self._state.snapshot().get("sources", {})
            payload["last_error"] = redact(str(exc))
            self._state.update_sources(payload)
            return

        # Outside the collect try on purpose: a scheduling fault is not a
        # collection failure and must not be reported as one. This does not
        # block - submit() starts a daemon thread or refuses immediately.
        try:
            self._prober.schedule(self._sources.last_targets(), manual=False)
        except Exception as exc:
            log.warning(f"Probe scheduling failed: {redact(str(exc))}")

    def fail(self, exc: BaseException) -> None:
        message = f"{type(exc).__name__}: {redact(str(exc))}"
        log.error(message)
        try:
            self._state.set_service_status(
                "error",
                ready=False,
                error=message,
            )
        except Exception:
            pass

    def stop(self) -> None:
        if self._stopped:
            return

        self._stopped = True

        try:
            self._state.set_service_status("stopped", ready=False)
        finally:
            log.info("Core service stopped")