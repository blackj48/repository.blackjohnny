"""
Source Hub contract publisher.  PHASE 2C (registration) + 2C-R (reachability).

Ownership
---------
This module is the SINGLE owner of every BJMAX.Sources.* and BJMAX.Source.N.*
window property. state.py must not write Sources.Total or Sources.Errors: two
writers on one key make the value depend on call order inside a single publish,
which is a heisenbug waiting for the first payload where the two computations
disagree. state.py keeps both numbers in runtime_state.json, where they are
state, not contract.

Registration and reachability are separate facts
------------------------------------------------
Source.N.State stays "registered" exactly as certified under 2C. A
disconnected SMB server is still registered with Kodi, and that is the truth
this field reports. Deregistration is observed the only correct way: the next
successful collect drops the item and _clear_item() wipes the slot.

Reachability is additive and lives under Source.N.Health.*, initially UNKNOWN
and only ever set by a real probe.

Privacy
-------
No path, host, share, user or credential is published. The probe identity is a
hash and stays inside the service. _safe() enforces this rather than trusting
callers, because a leak here would be invisible until someone posted a
screenshot.
"""

from __future__ import annotations

from typing import Any, Dict, List, Optional

CONTRACT = "2C"
HEALTH_CONTRACT = "2C-R"
UI_LIMIT = 12

MEDIA_KEYS = ("video", "music", "pictures", "files", "programs")

_ITEM_SUFFIXES = ("Label", "Media", "Protocol", "State",
                  "Health.State", "Health.Detail", "Health.CheckedAt")


def _safe(value: Any) -> str:
    text = "" if value is None else str(value)
    for token in ("://", "/", "\\"):
        if token in text:
            raise ValueError("sourcecontract: refusing to publish a path-like value")
    return text


def _set(window, key: str, value: Any) -> None:
    window.setProperty(key, "" if value is None else str(value))


def _set_safe(window, key: str, value: Any) -> None:
    """For fields that must never carry a path. Label is deliberately NOT one
    of these: a Kodi source label is user-chosen text and may legitimately
    contain a slash."""
    window.setProperty(key, _safe(value))


def _clear_item(window, index: int) -> None:
    prefix = "BJMAX.Source.{0}".format(index)
    for suffix in _ITEM_SUFFIXES:
        window.clearProperty("{0}.{1}".format(prefix, suffix))


def publish(window,
            sources: Dict[str, Any],
            health: Optional[Dict[str, Any]] = None,
            stalled: int = 0) -> Dict[str, Any]:
    """Publish the Source Hub contract to Window(10000).

    health maps probe identity -> {state, detail, checked_at}. It is keyed by
    identity and never by slot: slot N is a rendering position that can point
    at a different source after the user reorders sources, so a late result
    keyed by N would land on the wrong row. A result whose identity is no
    longer present simply never matches, which is the whole point.
    """
    items: List[Dict[str, Any]] = list(sources.get("items") or [])
    by_media = dict(sources.get("by_media") or {})
    errors = dict(sources.get("errors") or {})
    health = health or {}

    _set(window, "BJMAX.Sources.Contract", CONTRACT)
    _set(window, "BJMAX.Sources.HealthContract", HEALTH_CONTRACT)
    _set(window, "BJMAX.Sources.Total", len(items))
    _set(window, "BJMAX.Sources.Registered", len(items))
    # Collection errors per media type - NOT a count of dead sources. One
    # Files.GetSources failing does not mean JSON-RPC is down, and a source
    # being unreachable does not show up here at all.
    _set(window, "BJMAX.Sources.Errors", len(errors))
    _set(window, "BJMAX.Sources.LastCheck", sources.get("updated_at") or "")
    _set(window, "BJMAX.Sources.VisibleCount", min(len(items), UI_LIMIT))
    _set(window, "BJMAX.Sources.Overflow", max(0, len(items) - UI_LIMIT))
    # Probes whose call is still blocked past its deadline. Published because a
    # blocked probe is indistinguishable from a slow one on screen otherwise.
    _set(window, "BJMAX.Sources.Health.Stalled", int(stalled))

    for media in MEDIA_KEYS:
        _set(window, "BJMAX.Sources.Media.{0}".format(media), by_media.get(media, 0))

    tally = {"OK": 0, "UNREACHABLE": 0, "TIMEOUT": 0,
             "ERROR": 0, "SKIPPED": 0, "UNKNOWN": 0}

    for index in range(UI_LIMIT):
        if index >= len(items):
            _clear_item(window, index)
            continue

        item = items[index]
        prefix = "BJMAX.Source.{0}".format(index)
        _set(window, "{0}.Label".format(prefix), item.get("label") or "")
        _set_safe(window, "{0}.Media".format(prefix), item.get("media") or "")
        _set_safe(window, "{0}.Protocol".format(prefix), item.get("protocol") or "unknown")
        # unchanged, certified under 2C
        _set(window, "{0}.State".format(prefix), "registered")

        entry = health.get(item.get("identity") or "") or {}
        state = entry.get("state") or "UNKNOWN"
        _set_safe(window, "{0}.Health.State".format(prefix), state)
        _set_safe(window, "{0}.Health.Detail".format(prefix),
                  entry.get("detail") or "NEVER_CHECKED")
        _set(window, "{0}.Health.CheckedAt".format(prefix),
             entry.get("checked_at") or "")
        tally[state] = tally.get(state, 0) + 1

    for name, count in tally.items():
        _set(window, "BJMAX.Sources.Health.{0}".format(name.capitalize()), count)

    return {
        "contract": CONTRACT,
        "health_contract": HEALTH_CONTRACT,
        "registered": len(items),
        "errors": len(errors),
        "visible_count": min(len(items), UI_LIMIT),
        "overflow": max(0, len(items) - UI_LIMIT),
        "by_media": {m: int(by_media.get(m, 0) or 0) for m in MEDIA_KEYS},
        "health": dict(tally),
        "stalled": int(stalled),
    }
