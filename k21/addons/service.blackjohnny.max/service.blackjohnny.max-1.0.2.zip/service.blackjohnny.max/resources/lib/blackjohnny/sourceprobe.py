"""
Reachability probing for the Source Hub.  PHASE 2C-R.

Separate from sourcecontract.py on purpose: registration and reachability are
different facts. Files.GetSources proves Kodi has the source registered; it
says nothing about whether the far end answers. A disconnected SMB server stays
registered, and that is correct - deregistration is handled by the next
successful collect dropping the item, not by a failed probe.

Three constraints drive the whole design.

  1. A blocked VFS call cannot be cancelled. xbmcvfs.exists() against a dead
     SMB host blocks in the mount timeout inside the OS. There is no Python
     mechanism to abort it. A deadline can therefore only mark the RESULT as
     TIMEOUT for the UI; it cannot free the thread. So the thread is treated as
     lost until Kodi exits, concurrency is bounded, and a lost permit is
     surfaced (stalled) rather than hidden.

  2. Nothing runs in the service loop. Every probe runs on its own daemon
     thread; the loop only reads already-published results.

  3. A probe's identity must not be its slot. Slot N is a rendering position
     that can point at a different source after the user reorders sources, so a
     late result keyed by N would land on the wrong row. Identity is derived
     from (media, path) and never leaves the service - the path is hashed, and
     the hash is internal only.
"""

from __future__ import annotations

import hashlib
import os
import sys
import threading
import time
from datetime import datetime, timezone
from typing import Any, Dict, Optional, Tuple

from .redact import redact

try:
    import xbmcvfs
except ImportError:            # lets the pure logic be tested off-device
    xbmcvfs = None

# --------------------------------------------------------------- vocabulary
UNKNOWN = "UNKNOWN"            # never probed, or probe not applicable
OK = "OK"                      # far end answered
UNREACHABLE = "UNREACHABLE"    # answered "no"
TIMEOUT = "TIMEOUT"            # deadline passed, call still blocked
ERROR = "ERROR"                # the probe itself raised
SKIPPED = "SKIPPED"            # deliberately not probed automatically

HEALTH_STATES = (UNKNOWN, OK, UNREACHABLE, TIMEOUT, ERROR, SKIPPED)

# Closed detail vocabulary. The skin renders an unknown code as an empty cell,
# so this list is a contract - extend it here, and in the skin, together.
DETAIL_NEVER_CHECKED = "NEVER_CHECKED"
DETAIL_REACHABLE = "REACHABLE"
DETAIL_NOT_FOUND = "NOT_FOUND"
DETAIL_BLOCKED = "BLOCKED"
DETAIL_MANUAL_ONLY = "MANUAL_ONLY"      # network: not probed automatically
DETAIL_NOT_PROBEABLE = "NOT_PROBEABLE"  # plugin:// - listing runs 3rd-party code
DETAIL_PROBE_ERROR = "PROBE_ERROR"
DETAIL_IN_FLIGHT = "IN_FLIGHT"

# ------------------------------------------------------------ classification
_REMOTE_SCHEMES = (
    "smb", "nfs", "http", "https", "ftp", "ftps", "sftp",
    "dav", "davs", "upnp", "rtsp", "rtmp", "sptv", "stack",
)

LOCAL = "local"
REMOTE = "remote"
PLUGIN = "plugin"
OPAQUE = "opaque"          # special:// and anything we will not reason about

_DRIVE_REMOTE = 4          # DRIVE_REMOTE from winbase.h


def _windows_drive_is_remote(path: str) -> Optional[bool]:
    """True/False for a Windows drive letter, None when the question does not
    apply or cannot be answered.

    A mapped network drive looks exactly like a local path: Z:\\media is
    C:\\media's twin as far as string inspection goes, and probing it blocks
    like any other SMB target. GetDriveTypeW is the only reliable answer, so a
    drive letter is not called local until it has been asked.
    """
    if not sys.platform.startswith("win"):
        return None
    if len(path) < 3 or path[1] != ":" or path[2] not in ("\\", "/"):
        return None
    try:
        import ctypes
        root = path[:3].replace("/", "\\")
        kind = ctypes.windll.kernel32.GetDriveTypeW(ctypes.c_wchar_p(root))
        return kind == _DRIVE_REMOTE
    except Exception:
        return None            # unanswerable -> caller must not assume local


def classify(path: str) -> str:
    """Where a source lives, for scheduling purposes only. No I/O beyond the
    drive-type query, which does not touch the network for a local drive."""
    value = (path or "").strip()
    if not value:
        return OPAQUE

    lowered = value.lower()
    if lowered.startswith("plugin://"):
        return PLUGIN
    if lowered.startswith("special://"):
        return OPAQUE

    scheme = lowered.split("://", 1)[0] if "://" in lowered else ""
    if scheme:
        return REMOTE if scheme in _REMOTE_SCHEMES else OPAQUE

    if value.startswith("\\\\"):           # UNC
        return REMOTE

    remote = _windows_drive_is_remote(value)
    if remote is True:
        return REMOTE
    if remote is False:
        return LOCAL
    if remote is None and sys.platform.startswith("win"):
        # a drive letter we could not classify: treat as remote, because the
        # cost of guessing wrong that way is a manual probe, and the cost of
        # guessing wrong the other way is a blocked service thread.
        if len(value) >= 3 and value[1] == ":":
            return OPAQUE
    if value.startswith("/"):
        return LOCAL
    return OPAQUE


def identity(media: str, path: str) -> str:
    """Stable internal key for one source. Never published.

    Keyed on the path, not the label: two sources can share a label, and a
    label can be renamed without the source changing. The path is hashed so
    that no code downstream can accidentally publish it.
    """
    raw = "{0}\x00{1}".format(media or "", path or "")
    return hashlib.sha1(raw.encode("utf-8", "replace")).hexdigest()[:16]


def _utc_now() -> str:
    return datetime.now(timezone.utc).isoformat()


# ------------------------------------------------------------------- results
class ProbeResult:
    __slots__ = ("state", "detail", "checked_at", "started_at")

    def __init__(self, state: str, detail: str,
                 checked_at: str = "", started_at: float = 0.0) -> None:
        self.state = state
        self.detail = detail
        self.checked_at = checked_at
        self.started_at = started_at

    def as_dict(self) -> Dict[str, str]:
        return {"state": self.state, "detail": self.detail,
                "checked_at": self.checked_at}


class Prober:
    """Bounded, cancel-free probe runner.

    MAX_CONCURRENT is the number of threads that may be blocked at once. A
    thread that never returns keeps its permit forever; when every permit is
    lost the runner reports stalled and stops accepting work rather than
    spawning threads that cannot run.
    """

    MAX_CONCURRENT = 2
    DEADLINE_SECONDS = 20.0

    def __init__(self, logger=None) -> None:
        self._log = logger
        self._lock = threading.Lock()
        self._results: Dict[str, ProbeResult] = {}
        self._in_flight: Dict[str, float] = {}      # identity -> started_at
        self._permits = threading.BoundedSemaphore(self.MAX_CONCURRENT)

    # -- reading ---------------------------------------------------
    def result_for(self, ident: str) -> ProbeResult:
        with self._lock:
            started = self._in_flight.get(ident)
            if started is not None:
                if (time.time() - started) >= self.DEADLINE_SECONDS:
                    # The call is still blocked. Report it, do not pretend the
                    # thread was stopped - it was not.
                    return ProbeResult(TIMEOUT, DETAIL_BLOCKED, _utc_now(), started)
                return ProbeResult(UNKNOWN, DETAIL_IN_FLIGHT, "", started)
            found = self._results.get(ident)
        if found is not None:
            return found
        return ProbeResult(UNKNOWN, DETAIL_NEVER_CHECKED)

    @property
    def stalled(self) -> int:
        """Probes past their deadline whose thread is still blocked.

        Computed, not counted: a thread that eventually returns leaves
        _in_flight and stops being reported, so the number cannot drift away
        from reality the way a manually incremented counter would.
        """
        now = time.time()
        with self._lock:
            return sum(1 for started in self._in_flight.values()
                       if (now - started) >= self.DEADLINE_SECONDS)

    def busy(self) -> int:
        with self._lock:
            return len(self._in_flight)

    # -- writing ---------------------------------------------------
    def _record(self, ident: str, state: str, detail: str) -> None:
        with self._lock:
            self._results[ident] = ProbeResult(state, detail, _utc_now())

    def mark(self, ident: str, state: str, detail: str) -> None:
        """Record a decision that needed no I/O (SKIPPED, NOT_PROBEABLE)."""
        self._record(ident, state, detail)

    def submit(self, ident: str, path: str) -> bool:
        """Queue one probe. Returns False when it was not started.

        Refuses while the same identity is already in flight - a button press
        during a blocked probe must not pile up threads on the same dead host.
        """
        with self._lock:
            if ident in self._in_flight:
                return False
        if not self._permits.acquire(blocking=False):
            return False
        with self._lock:
            self._in_flight[ident] = time.time()

        thread = threading.Thread(
            target=self._run, args=(ident, path),
            name="bjmax-probe-" + ident, daemon=True)
        thread.start()
        return True

    def _run(self, ident: str, path: str) -> None:
        started = time.time()
        try:
            reachable = self._exists(path)
            state = OK if reachable else UNREACHABLE
            detail = DETAIL_REACHABLE if reachable else DETAIL_NOT_FOUND
        except Exception as exc:                       # noqa: BLE001
            state, detail = ERROR, DETAIL_PROBE_ERROR
            if self._log:
                # The message can contain the path. It used to be logged raw
                # on the reasoning that the log is not the contract surface -
                # but users post kodi.log publicly when they ask for help, so
                # the log is a publication surface in practice.
                self._log.error("probe {0} failed: {1}".format(
                    ident, redact(str(exc))))

        elapsed = time.time() - started
        with self._lock:
            self._in_flight.pop(ident, None)
            self._results[ident] = ProbeResult(state, detail, _utc_now(), started)
            if elapsed >= self.DEADLINE_SECONDS and self._log:
                self._log.warning(
                    "probe {0} returned after {1:.0f}s, past its deadline".format(
                        ident, elapsed))
        self._permits.release()

    def _exists(self, path: str) -> bool:
        if xbmcvfs is None:
            return os.path.exists(path)
        return bool(xbmcvfs.exists(path))

    # -- scheduling ------------------------------------------------
    def schedule(self, targets, manual: bool = False) -> Dict[str, int]:
        """One pass over probe targets: [{"identity", "path", "media"}].

        Targets are deliberately NOT the published items. The published items
        carry `identity` (a hash, safe to persist) and no path; the paths live
        only here and in the caller's memory, so runtime_state.json cannot
        acquire one by accident.

        manual=False - the automatic path: local sources only, and only after
                       classify() has confirmed the path does not resolve to a
                       network resource. Network sources are marked MANUAL_ONLY
                       rather than left blank, so the screen says why.
        manual=True  - the operator asked. Network sources are included.
        """
        counts = {"started": 0, "skipped": 0, "refused": 0}
        for target in targets:
            path = target.get("path") or ""
            ident = target.get("identity") or identity(target.get("media", ""), path)
            kind = classify(path)

            if kind == PLUGIN:
                self.mark(ident, SKIPPED, DETAIL_NOT_PROBEABLE)
                counts["skipped"] += 1
                continue
            if kind == OPAQUE:
                self.mark(ident, UNKNOWN, DETAIL_NEVER_CHECKED)
                counts["skipped"] += 1
                continue
            if kind == REMOTE and not manual:
                self.mark(ident, SKIPPED, DETAIL_MANUAL_ONLY)
                counts["skipped"] += 1
                continue

            if self.submit(ident, path):
                counts["started"] += 1
            else:
                counts["refused"] += 1
        return counts
