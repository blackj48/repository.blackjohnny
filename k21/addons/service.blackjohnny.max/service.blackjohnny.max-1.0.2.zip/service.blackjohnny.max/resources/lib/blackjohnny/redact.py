"""
Credential and path redaction.  PHASE 2C-P.

Anything the service PERSISTS (runtime_state.json) or LOGS (kodi.log) passes
through here first. Window properties do not: sourcecontract._safe() already
refuses a path-like value outright, which is the stricter rule and the right one
for a contract surface.

Threat model
------------
A Kodi source path routinely carries a credential:

    smb://bob:hunter2@nas.local/Media

Kodi puts that string into the exception text when the far end fails. Two places
used to copy that text verbatim - sourcehub stored it in runtime_state.json, and
sourceprobe wrote it to kodi.log. A user who posts their log on a forum to ask
for help publishes the credential with it. That is how this leaks in practice,
not through an attacker.

Policy: maximum removal
-----------------------
For OUR strings the policy is aggressive, because diagnosability survives
without the path. "smb://*** timed out" says everything "smb://bob:hunter2@
nas.local/Media timed out" says, for every purpose except attacking the user.

This is deliberately NOT the policy used for scrubbing kodi.log, which we do not
author: there, structure is preserved and only identity is removed, because a log
stripped of all paths is useless. Two surfaces, two threat models, two rules.

What this is not for
--------------------
Source LABELS. A Kodi source label is user-chosen text that may legitimately
contain a slash, and it is meant to be displayed. sourcecontract exempts it on
purpose; do not route it through here.

Known false positive
--------------------
A four-part version number (21.3.0.1) matches the IPv4 shape and is redacted.
This costs nothing: versions are published separately by the Health Center.
"""

import re

MARK = "***"

# scheme://[user[:pass]@]host[:port][/path]  - the whole authority and path go
_URL = re.compile(r'\b([A-Za-z][A-Za-z0-9+.\-]{1,15})://[^\s"\'<>|)\]]*')
# \\host\share\...
_UNC = re.compile(r'\\\\[^\s"\'<>|)\]]+')
# C:\... or C:/...
_DRIVE = re.compile(r'\b([A-Za-z]):[\\/][^\s"\'<>|)\]]*')
# /a/b...  - needs at least two separators, so "read/write" is left alone
_POSIX = re.compile(r'(?<![\w/])/(?:[^\s/"\'<>|)\]]+/)+[^\s/"\'<>|)\]]*')
_IPV4 = re.compile(r'\b(?:\d{1,3}\.){3}\d{1,3}\b')


def _ipv4(match):
    parts = match.group(0).split(".")
    if all(part.isdigit() and int(part) <= 255 for part in parts):
        return MARK
    return match.group(0)


def redact(value):
    """Return value as text with every path-like or address-like token removed.

    Order matters: URLs are consumed first so that their embedded host and path
    never reach the narrower patterns.
    """
    if value is None:
        return ""
    text = value if isinstance(value, str) else str(value)
    text = _URL.sub(lambda m: m.group(1) + "://" + MARK, text)
    text = _UNC.sub("\\\\\\\\" + MARK, text)
    text = _DRIVE.sub(lambda m: m.group(1) + ":\\" + MARK, text)
    text = _POSIX.sub("/" + MARK, text)
    text = _IPV4.sub(_ipv4, text)
    return text


def carries_secret(value):
    """True when redact() would change the value. For tests and lints."""
    text = "" if value is None else (value if isinstance(value, str) else str(value))
    return redact(text) != text
