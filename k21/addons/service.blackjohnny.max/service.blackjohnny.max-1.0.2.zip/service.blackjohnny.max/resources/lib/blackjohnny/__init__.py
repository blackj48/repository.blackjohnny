"""BLACKJOHNNY MAX core service package."""

__all__ = []