from __future__ import annotations

import itertools
import json
from typing import Any, Dict, Optional

import xbmc

from . import log
from .redact import redact


class KodiJsonRpcError(RuntimeError):
    pass


class KodiJsonRpc:
    """Kodi-internal JSON-RPC transport.

    Uses xbmc.executeJSONRPC(), which is always available to Kodi Python add-ons.
    No HTTP/TCP socket is used from inside the service.
    """

    def __init__(self) -> None:
        self._ids = itertools.count(1)

    def call(self, method: str, params: Optional[Dict[str, Any]] = None) -> Any:
        request_id = next(self._ids)
        payload: Dict[str, Any] = {
            "jsonrpc": "2.0",
            "id": request_id,
            "method": method,
        }

        if params is not None:
            payload["params"] = params

        raw = xbmc.executeJSONRPC(
            json.dumps(payload, ensure_ascii=False, separators=(",", ":"))
        )

        try:
            response = json.loads(raw)
        except Exception as exc:
            raise KodiJsonRpcError(
                f"{method}: invalid JSON-RPC response"
            ) from exc

        if response.get("id") != request_id:
            raise KodiJsonRpcError(f"{method}: response id mismatch")

        if "error" in response:
            err = response.get("error") or {}
            code = err.get("code")
            message = err.get("message", "JSON-RPC error")
            raise KodiJsonRpcError(f"{method}: {code} {message}")

        return response.get("result")

    def version(self) -> Dict[str, Any]:
        result = self.call("JSONRPC.Version")
        return result or {}

    def ping(self) -> bool:
        try:
            self.version()
            return True
        except Exception as exc:
            log.warning(f"JSON-RPC ping failed: {redact(str(exc))}")
            return False