from __future__ import annotations

import re
from typing import Any

import xbmc

_PREFIX = "[BLACKJOHNNY MAX SERVICE]"

_SECRET_PATTERNS = (
    re.compile(r"(?i)(token|access_token|refresh_token|api[_-]?key|apikey|password|passwd|pwd|secret)\s*[=:]\s*([^\s,;]+)"),
    re.compile(r"(?i)(https?://)([^/@:\s]+):([^/@\s]+)@"),
)


def _redact(value: Any) -> str:
    text = str(value)

    for pattern in _SECRET_PATTERNS:
        if pattern.pattern.startswith("(?i)(https?://)"):
            text = pattern.sub(r"\1***:***@", text)
        else:
            text = pattern.sub(r"\1=***", text)

    return text


def debug(message: Any) -> None:
    xbmc.log(f"{_PREFIX} {_redact(message)}", level=xbmc.LOGDEBUG)


def info(message: Any) -> None:
    xbmc.log(f"{_PREFIX} {_redact(message)}", level=xbmc.LOGINFO)


def warning(message: Any) -> None:
    xbmc.log(f"{_PREFIX} {_redact(message)}", level=xbmc.LOGWARNING)


def error(message: Any) -> None:
    xbmc.log(f"{_PREFIX} {_redact(message)}", level=xbmc.LOGERROR)