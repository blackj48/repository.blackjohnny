from __future__ import annotations

from datetime import datetime, timezone
from typing import Any, Dict

from .jsonrpc import KodiJsonRpc


def _utc_now() -> str:
    return datetime.now(timezone.utc).isoformat()


class HealthCenter:
    def __init__(self, rpc: KodiJsonRpc) -> None:
        self._rpc = rpc

    def collect(self) -> Dict[str, Any]:
        payload: Dict[str, Any] = {
            "ok": False,
            "updated_at": _utc_now(),
            "jsonrpc": False,
            "kodi": {},
            "active_players": 0,
        }

        version = self._rpc.version()
        payload["jsonrpc"] = True

        application = self._rpc.call(
            "Application.GetProperties",
            {"properties": ["name", "version"]},
        ) or {}

        players = self._rpc.call("Player.GetActivePlayers") or []

        payload["kodi"] = {
            "jsonrpc": version.get("version", {}),
            "application": application,
        }
        payload["active_players"] = len(players)
        payload["ok"] = True

        return payload