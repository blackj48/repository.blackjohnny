#!/usr/bin/env python3
"""Fail-closed privacy contract for BLACKJOHNNY MAX telemetry v0.1.

Only fields listed here may enter the local telemetry event log. An unexpected
field is an error rather than something silently accepted. This makes future
network transport safer: the event schema must be deliberately expanded before
new data can leave the runtime boundary.
"""

import uuid

POLICY_VERSION = 1
EVENT_SCHEMA_VERSION = 1

BASE_FIELDS = {
    "schema", "policy", "event", "date_utc", "installation_id",
    "version", "kodi", "platform",
}
EVENT_FIELDS = {
    "install": set(),
    "active": set(),
    "update": {"from_version", "to_version"},
    "rating": {"rating"},
}

# Explicitly documented examples of data this subsystem must never collect.
FORBIDDEN_CATEGORIES = (
    "real_debrid_credentials",
    "streaming_credentials",
    "email",
    "account_name",
    "ip_address",
    "mac_address",
    "hardware_serial",
    "watch_history",
    "search_history",
    "media_titles",
    "installed_addons",
    "repository_list",
    "file_paths",
)

PLATFORMS = {"windows", "android", "linux", "macos", "ios", "unknown"}

PRIVACY_SUMMARY_EL = (
    "Opt-in μόνο. Συλλέγονται μόνο: τυχαίο installation ID, έκδοση "
    "BLACKJOHNNY MAX, έκδοση Kodi, λειτουργικό σύστημα και τύπος event. "
    "Δεν συλλέγονται λογαριασμοί, Real-Debrid, IP, ιστορικό, τίτλοι media, "
    "εγκατεστημένα πρόσθετα ή διαδρομές αρχείων. Στο v0.1 δεν υπάρχει "
    "καμία μετάδοση μέσω Internet."
)

PRIVACY_SUMMARY_EN = (
    "Opt-in only. Collected fields are limited to a random installation ID, "
    "BLACKJOHNNY MAX version, Kodi version, operating system and event type. "
    "Accounts, Real-Debrid data, IP addresses, history, media titles, installed "
    "add-ons and file paths are never collected. v0.1 performs no Internet "
    "transmission."
)


def _short_string(value, field, maximum=64):
    if value is None:
        raise ValueError("{0} is required".format(field))
    text = str(value).strip()
    if not text:
        raise ValueError("{0} is empty".format(field))
    if len(text) > maximum:
        raise ValueError("{0} is too long".format(field))
    return text


def _validate_uuid4(value):
    text = _short_string(value, "installation_id", 64)
    try:
        parsed = uuid.UUID(text)
    except (ValueError, AttributeError, TypeError):
        raise ValueError("installation_id is not a UUID")
    if parsed.version != 4:
        raise ValueError("installation_id is not UUIDv4")
    return str(parsed)


def sanitize_event(payload):
    """Validate and return a new event containing only approved fields."""
    if not isinstance(payload, dict):
        raise ValueError("event payload must be a dict")

    event = _short_string(payload.get("event"), "event", 16).lower()
    if event not in EVENT_FIELDS:
        raise ValueError("unsupported telemetry event: {0}".format(event))

    allowed = BASE_FIELDS | EVENT_FIELDS[event]
    unexpected = set(payload) - allowed
    if unexpected:
        raise ValueError("unexpected telemetry field(s): {0}".format(
            ", ".join(sorted(unexpected))))

    result = {
        "schema": EVENT_SCHEMA_VERSION,
        "policy": POLICY_VERSION,
        "event": event,
        "date_utc": _short_string(payload.get("date_utc"), "date_utc", 10),
        "installation_id": _validate_uuid4(payload.get("installation_id")),
        "version": _short_string(payload.get("version"), "version", 32),
        "kodi": _short_string(payload.get("kodi"), "kodi", 64),
        "platform": _short_string(payload.get("platform"), "platform", 16).lower(),
    }
    if result["platform"] not in PLATFORMS:
        result["platform"] = "unknown"

    if event == "update":
        result["from_version"] = _short_string(
            payload.get("from_version"), "from_version", 32)
        result["to_version"] = _short_string(
            payload.get("to_version"), "to_version", 32)
    elif event == "rating":
        try:
            rating = int(payload.get("rating"))
        except (TypeError, ValueError):
            raise ValueError("rating must be an integer")
        if rating < 1 or rating > 5:
            raise ValueError("rating must be between 1 and 5")
        result["rating"] = rating

    return result
