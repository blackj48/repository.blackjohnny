#!/usr/bin/env python3
"""Stable anonymous installation identifier for BLACKJOHNNY MAX telemetry.

The identifier is created only after explicit telemetry opt-in. It is a random
UUIDv4 and is never derived from hardware, account names, network addresses,
or Kodi profile paths.
"""

import json
import os
import uuid

SCHEMA_VERSION = 1


def _atomic_write_json(path, payload):
    directory = os.path.dirname(path)
    if directory:
        os.makedirs(directory, exist_ok=True)
    tmp = path + ".tmp"
    data = json.dumps(payload, ensure_ascii=False, sort_keys=True,
                      separators=(",", ":")) + "\n"
    with open(tmp, "w", encoding="utf-8", newline="\n") as fh:
        fh.write(data)
        fh.flush()
        try:
            os.fsync(fh.fileno())
        except OSError:
            pass
    os.replace(tmp, path)


def _valid_uuid4(value):
    try:
        parsed = uuid.UUID(str(value))
    except (ValueError, AttributeError, TypeError):
        return None
    if parsed.version != 4:
        return None
    return str(parsed)


def load_installation_id(path):
    """Return a valid existing UUIDv4, otherwise None."""
    try:
        with open(path, "r", encoding="utf-8") as fh:
            payload = json.load(fh)
    except (OSError, ValueError, TypeError):
        return None
    if not isinstance(payload, dict):
        return None
    return _valid_uuid4(payload.get("installation_id"))


def get_or_create_installation_id(path):
    """Return the stable anonymous UUIDv4 stored at *path*.

    Callers must enforce consent before invoking this function. That property is
    intentional: opting out means no telemetry identifier is created at all.
    """
    current = load_installation_id(path)
    if current:
        return current
    value = str(uuid.uuid4())
    _atomic_write_json(path, {
        "schema": SCHEMA_VERSION,
        "installation_id": value,
    })
    return value
