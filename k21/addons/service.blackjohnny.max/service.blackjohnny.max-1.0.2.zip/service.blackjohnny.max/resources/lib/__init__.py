"""BLACKJOHNNY MAX service support library."""
