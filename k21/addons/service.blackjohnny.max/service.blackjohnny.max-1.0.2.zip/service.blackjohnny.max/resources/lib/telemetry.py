#!/usr/bin/env python3
"""Privacy-first local telemetry engine for BLACKJOHNNY MAX v0.1.

This module deliberately contains no network code. It records a tiny, strict,
opt-in event stream inside the service add-on profile. A future transport layer
must be a separate reviewed module and may only consume the sanitized events
written here.
"""

from datetime import datetime, timezone
import json
import os
import shutil
import time

from installation_id import get_or_create_installation_id, load_installation_id
from privacy import sanitize_event

STATE_SCHEMA = 1
DEFAULT_ACTIVE_INTERVAL_DAYS = 7


def _atomic_write_json(path, payload):
    directory = os.path.dirname(path)
    if directory:
        os.makedirs(directory, exist_ok=True)
    tmp = path + ".tmp"
    text = json.dumps(payload, ensure_ascii=False, sort_keys=True,
                      separators=(",", ":")) + "\n"
    with open(tmp, "w", encoding="utf-8", newline="\n") as fh:
        fh.write(text)
        fh.flush()
        try:
            os.fsync(fh.fileno())
        except OSError:
            pass
    os.replace(tmp, path)


def _event_date_utc(epoch_seconds):
    return datetime.fromtimestamp(float(epoch_seconds), tz=timezone.utc).strftime("%Y-%m-%d")


class LocalTelemetry:
    """Local-only telemetry store and event state machine.

    No directory, UUID, state or event file is created while telemetry is off.
    """

    def __init__(self, profile_dir, active_interval_days=DEFAULT_ACTIVE_INTERVAL_DAYS):
        self.profile_dir = os.path.abspath(profile_dir)
        self.root = os.path.join(self.profile_dir, "telemetry")
        self.installation_file = os.path.join(self.root, "installation.json")
        self.state_file = os.path.join(self.root, "state.json")
        self.events_file = os.path.join(self.root, "events.jsonl")
        self.active_interval_seconds = max(1, int(active_interval_days)) * 86400

    def _load_state(self):
        try:
            with open(self.state_file, "r", encoding="utf-8") as fh:
                data = json.load(fh)
        except (OSError, ValueError, TypeError):
            return {}
        return data if isinstance(data, dict) else {}

    def _save_state(self, state):
        state = dict(state)
        state["schema"] = STATE_SCHEMA
        _atomic_write_json(self.state_file, state)

    def _append(self, event):
        clean = sanitize_event(event)
        os.makedirs(self.root, exist_ok=True)
        line = json.dumps(clean, ensure_ascii=False, sort_keys=True,
                          separators=(",", ":")) + "\n"
        with open(self.events_file, "a", encoding="utf-8", newline="\n") as fh:
            fh.write(line)
            fh.flush()
            try:
                os.fsync(fh.fileno())
            except OSError:
                pass
        return clean

    def _base_event(self, event, installation_id, version, kodi, platform, now):
        return {
            "schema": 1,
            "policy": 1,
            "event": event,
            "date_utc": _event_date_utc(now),
            "installation_id": installation_id,
            "version": version,
            "kodi": kodi,
            "platform": platform,
        }

    def sync(self, enabled, version, kodi, platform, rating=0, now=None):
        """Record due events and return the event names written this call.

        First telemetry-enabled execution records ``install``. Subsequent
        version changes record ``update``. ``active`` is at most weekly.
        ``rating`` is written only when the 1-5 value changes.
        """
        if not enabled:
            return []

        now = time.time() if now is None else float(now)
        installation_id = get_or_create_installation_id(self.installation_file)
        state = self._load_state()
        written = []

        first_seen = not state.get("first_seen_version")
        if first_seen:
            event = self._base_event(
                "install", installation_id, version, kodi, platform, now)
            self._append(event)
            written.append("install")
            state["first_seen_version"] = str(version)
            state["last_seen_version"] = str(version)
            # The install itself demonstrates activity; do not emit a second
            # active event on the same first run.
            state["last_active_ts"] = now
            state.setdefault("last_rating", 0)
        else:
            previous = str(state.get("last_seen_version") or "")
            if previous and previous != str(version):
                event = self._base_event(
                    "update", installation_id, version, kodi, platform, now)
                event["from_version"] = previous
                event["to_version"] = str(version)
                self._append(event)
                written.append("update")
                state["last_seen_version"] = str(version)
            elif not previous:
                state["last_seen_version"] = str(version)

            last_active = float(state.get("last_active_ts") or 0.0)
            if last_active <= 0 or (now - last_active) >= self.active_interval_seconds:
                event = self._base_event(
                    "active", installation_id, version, kodi, platform, now)
                self._append(event)
                written.append("active")
                state["last_active_ts"] = now

        try:
            rating_value = int(rating or 0)
        except (TypeError, ValueError):
            rating_value = 0
        previous_rating = int(state.get("last_rating") or 0)
        if 1 <= rating_value <= 5 and rating_value != previous_rating:
            event = self._base_event(
                "rating", installation_id, version, kodi, platform, now)
            event["rating"] = rating_value
            self._append(event)
            written.append("rating")
            state["last_rating"] = rating_value

        self._save_state(state)
        return written

    def read_events(self, limit=50):
        if not os.path.exists(self.events_file):
            return []
        rows = []
        try:
            with open(self.events_file, "r", encoding="utf-8") as fh:
                for line in fh:
                    line = line.strip()
                    if not line:
                        continue
                    try:
                        rows.append(json.loads(line))
                    except ValueError:
                        continue
        except OSError:
            return []
        if limit is None or limit <= 0:
            return rows
        return rows[-int(limit):]

    def status(self, enabled):
        state = self._load_state()
        events = self.read_events(limit=1000000)
        installation_id = load_installation_id(self.installation_file)
        return {
            "mode": "local_only",
            "network_transmission": False,
            "enabled": bool(enabled),
            "installation_id": installation_id,
            "event_count": len(events),
            "last_event": events[-1] if events else None,
            "first_seen_version": state.get("first_seen_version"),
            "last_seen_version": state.get("last_seen_version"),
            "last_rating": int(state.get("last_rating") or 0),
        }

    def reset(self):
        """Delete all local telemetry state and the anonymous UUID."""
        if os.path.isdir(self.root):
            shutil.rmtree(self.root)
        return not os.path.exists(self.root)
