from __future__ import annotations

import os
import sys

import xbmc
import xbmcaddon
import xbmcvfs

ADDON = xbmcaddon.Addon()
ADDON_PATH = xbmcvfs.translatePath(ADDON.getAddonInfo("path"))
LIB_PATH = os.path.join(ADDON_PATH, "resources", "lib")

if LIB_PATH not in sys.path:
    sys.path.insert(0, LIB_PATH)

from blackjohnny.orchestrator import Orchestrator  # noqa: E402


def main() -> None:
    monitor = xbmc.Monitor()
    orchestrator = Orchestrator(addon=ADDON, monitor=monitor)

    try:
        orchestrator.start()

        while not monitor.abortRequested():
            orchestrator.tick()

            if monitor.waitForAbort(1.0):
                break
    except Exception as exc:
        orchestrator.fail(exc)
        raise
    finally:
        orchestrator.stop()


if __name__ == "__main__":
    main()