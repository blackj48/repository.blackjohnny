#!/usr/bin/env python3
"""On-demand actions for service.blackjohnny.max."""

import sys

import xbmcgui

import service as svc
from service import Config, Logger, Maintenance, TaskResult


def parse_args(argv):
    args = {}
    for item in argv[1:]:
        if "=" in item:
            key, _, value = item.partition("=")
            args[key.strip()] = value.strip()
    return args


def notify(heading, message, icon=xbmcgui.NOTIFICATION_INFO):
    xbmcgui.Dialog().notification(heading, message, icon, 5000)


def show_telemetry_status():
    xbmcgui.Dialog().textviewer(
        "BLACKJOHNNY MAX - Telemetry",
        svc.telemetry_status_text(),
    )


def manage_telemetry():
    choice = xbmcgui.Dialog().select(
        "BLACKJOHNNY MAX - Telemetry",
        [
            "Κατάσταση & ιδιωτικότητα",
            "Άνοιγμα ρυθμίσεων υπηρεσίας",
            "Διαγραφή τοπικών δεδομένων telemetry",
        ],
    )
    if choice == 0:
        show_telemetry_status()
    elif choice == 1:
        svc.ADDON.openSettings()
    elif choice == 2:
        if xbmcgui.Dialog().yesno(
            "BLACKJOHNNY MAX",
            "Να διαγραφούν το anonymous installation ID και όλα τα τοπικά telemetry events;",
        ):
            ok = svc.create_telemetry().reset()
            try:
                svc.ADDON.setSetting("telemetry_rating", "0")
            except Exception:
                pass
            if ok:
                notify("BLACKJOHNNY MAX", "Τα τοπικά δεδομένα telemetry διαγράφηκαν")
            else:
                notify("BLACKJOHNNY MAX", "Η διαγραφή telemetry απέτυχε",
                       xbmcgui.NOTIFICATION_ERROR)


def main(argv):
    args = parse_args(argv)
    action = args.get("action", "")

    log = Logger()
    cfg = Config(logger=log)
    log.set_level(cfg.get("log_level"))

    if action == "clear_cache":
        maint = Maintenance(cfg, log)
        result = maint._safe(maint.clear_cache)
        if result == TaskResult.OK:
            notify("BLACKJOHNNY MAX", "Ο καθαρισμός ολοκληρώθηκε")
        elif result == TaskResult.SKIPPED:
            notify("BLACKJOHNNY MAX", "Παραλείφθηκε: δεν έχει υλοποιηθεί",
                   xbmcgui.NOTIFICATION_WARNING)
        else:
            notify("BLACKJOHNNY MAX", "Ο καθαρισμός απέτυχε - δες το service.log",
                   xbmcgui.NOTIFICATION_ERROR)

    elif action == "run_maintenance":
        Maintenance(cfg, log).run()
        notify("BLACKJOHNNY MAX", "Η συντήρηση ολοκληρώθηκε")

    elif action == "view_logs":
        try:
            with open(log.path, "r", encoding="utf-8") as fh:
                text = fh.read()[-20000:]
        except OSError:
            text = "Δεν βρέθηκε αρχείο καταγραφής."
        xbmcgui.Dialog().textviewer("BLACKJOHNNY MAX - service.log", text)

    elif action == "telemetry_status":
        show_telemetry_status()

    elif action == "telemetry_manage":
        manage_telemetry()

    elif action == "telemetry_reset":
        ok = svc.create_telemetry().reset()
        notify("BLACKJOHNNY MAX",
               "Τα τοπικά δεδομένα telemetry διαγράφηκαν" if ok else "Η διαγραφή απέτυχε",
               xbmcgui.NOTIFICATION_INFO if ok else xbmcgui.NOTIFICATION_ERROR)

    else:
        notify("BLACKJOHNNY MAX", "Άγνωστη ενέργεια: {0}".format(action or "(κενή)"),
               xbmcgui.NOTIFICATION_WARNING)


if __name__ == "__main__":
    main(sys.argv)
