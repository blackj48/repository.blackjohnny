"""Playback lifecycle token, plus one fixed-path check: is the sync engine installed?
D221 (STAB104D): the skin shows «Συγχρονισμός» only when BJMAX.SubSync.Ready is set.
No file discovery, no sockets, no network calls."""
import time
import uuid
from pathlib import Path
import xbmc
import xbmcaddon
import xbmcgui
import xbmcvfs

WINDOW = xbmcgui.Window(10000)
TOKEN = 'BJMAX.SubSync.Session'
HEARTBEAT = 'BJMAX.SubSync.Heartbeat'
UNDO = 'BJMAX.SubSync.Undo'
READY = 'BJMAX.SubSync.Ready'
# The one path default.py runs the engine from (ENGINE there) - checked, never searched for.
ENGINE = Path(xbmcvfs.translatePath(xbmcaddon.Addon().getAddonInfo('profile'))) / 'engine/venv/Scripts/python.exe'


def report_engine():
    if ENGINE.is_file():
        WINDOW.setProperty(READY, 'true')
    else:
        WINDOW.clearProperty(READY)

class Lifecycle(xbmc.Player):
    def reset(self):
        WINDOW.setProperty(TOKEN, uuid.uuid4().hex)
        WINDOW.clearProperty(UNDO)
    def onPlayBackStarted(self):
        self.reset()
    def onPlayBackStopped(self):
        self.reset()
    def onPlayBackEnded(self):
        self.reset()
    def onPlayBackError(self):
        self.reset()

monitor = xbmc.Monitor()
player = Lifecycle()
player.reset()
ticks = 0
try:
    while not monitor.abortRequested():
        WINDOW.setProperty(HEARTBEAT, str(time.time()))
        if ticks % 30 == 0:          # at start, then every 30 s: an engine installed later is seen
            report_engine()
        ticks += 1
        if monitor.waitForAbort(1):
            break
finally:
    WINDOW.clearProperty(TOKEN)
    WINDOW.clearProperty(HEARTBEAT)
    WINDOW.clearProperty(UNDO)
    WINDOW.clearProperty(READY)
