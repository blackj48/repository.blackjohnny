# -*- coding: utf-8 -*-
"""BLACKJOHNNY subtitle sync: local reference, explicit binding, guarded reload/undo.
User-facing text is plain Greek (STAB104D, D220); internal names never reach the screen."""
import json
import os
from pathlib import Path
import subprocess
import sys
import time
import uuid

import xbmc
import xbmcaddon
import xbmcgui
import xbmcvfs

ADDON = xbmcaddon.Addon()
BASE = Path(xbmcvfs.translatePath(ADDON.getAddonInfo('path')))
PROFILE = Path(xbmcvfs.translatePath(ADDON.getAddonInfo('profile')))
LIB = BASE / 'resources/lib'
sys.path.insert(0, str(LIB))
from safety import read_srt, eligible, changed_candidates, digest, same_playback, same_selection

TITLE = 'Συγχρονισμός υποτίτλων'
WINDOW = xbmcgui.Window(10000)
MONITOR = xbmc.Monitor()
UNDO_PROP = 'BJMAX.SubSync.Undo'
ENGINE = PROFILE / 'engine/venv/Scripts/python.exe'


def rpc(method, params=None):
    request = {'jsonrpc': '2.0', 'id': 1, 'method': method}
    if params is not None:
        request['params'] = params
    response = json.loads(xbmc.executeJSONRPC(json.dumps(request)))
    if 'error' in response or 'result' not in response:
        raise RuntimeError('kodi-rpc')
    return response['result']


def read_json(path):
    try:
        return json.loads(Path(path).read_text(encoding='utf-8'))
    except (OSError, ValueError):
        return {}


def write_json(path, value):
    path = Path(path)
    path.parent.mkdir(parents=True, exist_ok=True)
    temp = path.with_name(path.name + '.' + uuid.uuid4().hex + '.tmp')
    try:
        temp.write_text(json.dumps(value, ensure_ascii=False), encoding='utf-8')
        os.replace(temp, path)
    finally:
        if temp.exists():
            temp.unlink()


def tell(message):
    xbmcgui.Dialog().ok(TITLE, message)


def state():
    token = WINDOW.getProperty('BJMAX.SubSync.Session')
    try:
        age = time.time() - float(WINDOW.getProperty('BJMAX.SubSync.Heartbeat'))
    except ValueError:
        age = 999
    if not token or not 0 <= age < 5 or not xbmc.Player().isPlayingVideo():
        raise RuntimeError('playback-monitor-unavailable')
    players = rpc('Player.GetActivePlayers')
    ids = [p['playerid'] for p in players if p.get('type') == 'video']
    if len(ids) != 1:
        raise RuntimeError('player-ambiguous')
    props = rpc('Player.GetProperties', {'playerid': ids[0], 'properties': ['currentsubtitle', 'subtitleenabled', 'speed']})
    playing = xbmc.Player().getPlayingFile()
    if token != WINDOW.getProperty('BJMAX.SubSync.Session'):
        raise RuntimeError('playback-changed')
    return {'session': token, 'file': digest(playing.encode('utf-8')), 'playerid': ids[0],
            'subtitle': props.get('currentsubtitle') or {}, 'enabled': props.get('subtitleenabled', False),
            'speed': props.get('speed', 0)}


def local_reference():
    raw = xbmc.Player().getPlayingFile()
    if raw.startswith('special://'):
        raw = xbmcvfs.translatePath(raw)
    if '://' in raw or '|' in raw or not Path(raw).is_file():
        raise ValueError('local-reference-required')
    return str(Path(raw).resolve())


def candidates():
    roots = [Path(xbmcvfs.translatePath('special://temp/'))]
    try:
        roots.append(Path(local_reference()).parent)
    except ValueError:
        pass
    records = {}
    # Bounded traversal; no scanning the full userdata tree or provider settings.
    deadline = time.monotonic() + 4
    count = 0
    for root in roots:
        if not root.is_dir():
            continue
        for cur, dirs, files in os.walk(root, followlinks=False):
            dirs[:] = [d for d in dirs if not (Path(cur)/d).is_symlink()]
            if len(Path(cur).relative_to(root).parts) >= 2:
                dirs[:] = []
            for name in files:
                count += 1
                if count > 4000 or time.monotonic() > deadline:
                    return records, False
                if not name.lower().endswith('.srt') or '.bj-synced' in name.lower():
                    continue
                p = str(Path(cur, name).absolute())
                try:
                    _, records[p] = read_srt(p)
                except (OSError, ValueError):
                    continue
    return records, True


def stable_copy(path, destination):
    data, first = read_srt(path)
    if MONITOR.waitForAbort(.4):
        raise RuntimeError('aborted')
    data2, second = read_srt(path)
    if first != second or data != data2:
        raise ValueError('subtitle-changing')
    Path(destination).write_bytes(data)
    return first['sha256']


def load(path, expected):
    if not same_selection(expected, state()):
        raise RuntimeError('selection-changed')
    # SetSubtitle JSON-RPC selects existing streams. The Python API loads a file.
    player = xbmc.Player()
    player.setSubtitles(str(path))
    # This API returns no acknowledgement; current metadata cannot prove file identity.
    if MONITOR.waitForAbort(.5):
        raise RuntimeError('aborted')
    current = state()
    if not same_playback(expected, current):
        raise RuntimeError('playback-changed')
    return current


def snapshot_download():
    before = state()
    records, complete = candidates()
    if not same_selection(before, state()):
        raise RuntimeError('selection-changed')
    write_json(PROFILE/'snapshot.json', {'session': before['session'], 'file': before['file'],
               'created': time.time(), 'files': records, 'complete': complete})
    # An attempted new download invalidates the previous explicit binding.
    write_json(PROFILE/'binding.json', {})
    WINDOW.clearProperty(UNDO_PROP)
    xbmc.executebuiltin('Dialog.Close(VideoOSD)')
    xbmc.executebuiltin('ActivateWindow(subtitlesearch)')


def bind_file(path, before):
    job = PROFILE/'sessions'/uuid.uuid4().hex
    job.mkdir(parents=True)
    original = job/'original.srt'
    sha = stable_copy(path, original)
    bound = load(original, before)
    record = {'state': bound, 'original': str(original), 'sha256': sha}
    write_json(PROFILE/'binding.json', record)
    WINDOW.clearProperty(UNDO_PROP)
    return record


def browse():
    before = state()
    chosen = xbmcgui.Dialog().browseSingle(1, 'Επιλογή υποτίτλου (SRT)', 'files', '.srt', False, False)
    if not chosen:
        return
    if '://' in chosen:
        tell('Διάλεξε ένα αρχείο SRT αποθηκευμένο σε αυτή τη συσκευή.')
        return
    bind_file(chosen, before)


def resolve(before):
    binding = read_json(PROFILE/'binding.json')
    if same_selection(binding.get('state'), before):
        _, info = read_srt(binding['original'])
        if info['sha256'] == binding.get('sha256'):
            return binding
    snap = read_json(PROFILE/'snapshot.json')
    if not eligible(snap, before['session'], time.time()) or snap.get('file') != before['file'] or not snap.get('complete'):
        tell('Δεν βρέθηκε υπότιτλος που κατέβηκε σε αυτή την αναπαραγωγή.\nΧρησιμοποίησε «Λήψη υποτίτλων» ή «Υπότιτλος από αρχείο».')
        return None
    current, complete = candidates()
    if not complete:
        tell('Ο έλεγχος των αρχείων δεν ολοκληρώθηκε. Διάλεξε τον υπότιτλο από «Υπότιτλος από αρχείο».')
        return None
    found = changed_candidates(snap['files'], current)
    if not found:
        tell('Δεν βρέθηκε αρχείο υποτίτλων (SRT) γι\' αυτή την αναπαραγωγή.\nΔιάλεξέ το από «Υπότιτλος από αρχείο».')
        return None
    labels = [Path(p).name for p in found]
    idx = xbmcgui.Dialog().select('Επιβεβαίωσε τον υπότιτλο που κατέβασες', labels)
    if idx < 0:
        return None
    # A deliberate selection establishes the source. Recency never authorizes reload.
    return bind_file(found[idx], before)


def stop_process(proc):
    if proc is None or proc.poll() is not None:
        return
    if os.name == 'nt':
        subprocess.run(['taskkill', '/PID', str(proc.pid), '/T', '/F'], stdout=subprocess.DEVNULL,
                       stderr=subprocess.DEVNULL, timeout=10, creationflags=getattr(subprocess, 'CREATE_NO_WINDOW', 0))
    else:
        import signal
        os.killpg(proc.pid, signal.SIGKILL)
    proc.wait(timeout=10)


def undo():
    saved = read_json(PROFILE/'undo.json')
    current = state()
    if not same_selection(saved.get('state'), current):
        WINDOW.clearProperty(UNDO_PROP)
        tell('Η αναίρεση αφορά άλλον υπότιτλο ή άλλη αναπαραγωγή.')
        return
    _, info = read_srt(saved['original'])
    if info['sha256'] != saved.get('sha256'):
        raise ValueError('undo-copy-changed')
    restored = load(saved['original'], current)
    write_json(PROFILE/'binding.json', {'state': restored, 'original': saved['original'], 'sha256': saved['sha256']})
    write_json(PROFILE/'undo.json', {})
    WINDOW.clearProperty(UNDO_PROP)
    tell('Επανήλθε ο αρχικός υπότιτλος.\nΗ χειροκίνητη καθυστέρηση δεν άλλαξε.')


def auto():
    before = state()
    reference = local_reference()  # 1C network references deliberately excluded.
    if not ENGINE.is_file():
        tell('Η μηχανή συγχρονισμού (ffsubsync) δεν είναι εγκατεστημένη σε αυτή τη συσκευή.')
        return
    if not before['enabled'] or not before['subtitle']:
        tell('Ενεργοποίησε πρώτα έναν υπότιτλο.')
        return
    binding = resolve(before)
    if not binding:
        return
    expected = binding['state']
    # Kodi 21 public interfaces in this package do not expose a proven absolute
    # subtitle-delay setter. Do not simulate one with repeated +/- actions.
    if not xbmcgui.Dialog().yesno(TITLE, 'Για σωστό αποτέλεσμα η καθυστέρηση υποτίτλων πρέπει να είναι 0,000 s.\nΕίναι μηδενική;', nolabel='Επιστροφή', yeslabel='Ναι, συνέχεια'):
        return
    if not same_selection(expected, state()):
        raise RuntimeError('selection-changed')
    job = PROFILE/'sessions'/uuid.uuid4().hex
    job.mkdir(parents=True)
    source = job/'input.srt'
    stable_copy(binding['original'], source)
    output = job/'output.bj-synced.srt'
    result_path = job/'result.json'
    progress_path = job/'progress.json'
    proc = None
    dlg = xbmcgui.DialogProgress()
    dlg.create(TITLE, 'Ανάλυση ήχου και υποτίτλων…')
    try:
        proc = subprocess.Popen([str(ENGINE), str(LIB/'engine_runner.py'), '--result', str(result_path), '--progress', str(progress_path)],
            stdin=subprocess.PIPE, stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL, text=True,
            creationflags=getattr(subprocess, 'CREATE_NO_WINDOW', 0), start_new_session=(os.name != 'nt'))
        proc.stdin.write(json.dumps({'reference': reference, 'subtitle': str(source), 'output': str(output)}))
        proc.stdin.close()
        start = time.monotonic()
        while proc.poll() is None:
            if dlg.iscanceled() or MONITOR.abortRequested() or time.monotonic()-start > 600:
                stop_process(proc)
                return
            if not same_selection(expected, state()):
                stop_process(proc)
                raise RuntimeError('selection-changed')
            progress = read_json(progress_path)
            fraction = progress.get('fraction')
            if isinstance(fraction, (int, float)) and 0 <= fraction <= 1:
                dlg.update(min(99, int(100*fraction)), 'Ανάλυση ήχου και υποτίτλων…')
            else:
                dlg.update(0, 'Ανάλυση ήχου και υποτίτλων…')
            MONITOR.waitForAbort(.3)
        result = read_json(result_path)
        if proc.returncode != 0 or not result.get('sync_was_successful'):
            tell('Ο συγχρονισμός δεν ολοκληρώθηκε. Ο υπότιτλος δεν άλλαξε.')
            return
        _, output_info = read_srt(output)
        _, source_info = read_srt(source)
        if output_info['cues'] != source_info['cues']:
            raise ValueError('output-cue-count')
        # Revalidate immutable undo copy and current playback immediately before mutation.
        _, orig_info = read_srt(binding['original'])
        if orig_info['sha256'] != binding['sha256']:
            raise ValueError('original-changed')
        applied = load(output, expected)
        write_json(PROFILE/'undo.json', {'state': applied, 'original': binding['original'], 'sha256': binding['sha256']})
        write_json(PROFILE/'binding.json', {})
        WINDOW.setProperty(UNDO_PROP, 'true')
        dlg.close()
        tell('Ο συγχρονισμένος υπότιτλος φορτώθηκε.\nΈλεγξε ότι ταιριάζει με την ομιλία. Αν όχι, πάτα «Αναίρεση συγχρονισμού».')
    finally:
        stop_process(proc)
        dlg.close()


def main():
    PROFILE.mkdir(parents=True, exist_ok=True)
    args = dict(a.split('=', 1) for a in sys.argv[1:] if '=' in a)
    mode = args.get('mode', 'menu')
    # O_EXCL prevents simultaneous auto/browse/download/undo writers across interpreters.
    lock = PROFILE/'operation.lock'
    try:
        fd = os.open(str(lock), os.O_CREAT | os.O_EXCL | os.O_WRONLY)
    except FileExistsError:
        tell('Τρέχει ήδη ένας συγχρονισμός. Αν το Kodi είχε κλείσει απότομα, διάγραψε το αρχείο operation.lock από τον φάκελο δεδομένων του πρόσθετου.')
        return
    os.close(fd)
    try:
        if mode == 'menu':
            i = xbmcgui.Dialog().select(TITLE, ['Συγχρονισμός', 'Αναίρεση συγχρονισμού', 'Επιλογή αρχείου SRT'])
            mode = ('auto', 'undo', 'browse')[i] if i >= 0 else ''
        actions = {'auto': auto, 'undo': undo, 'download': snapshot_download, 'browse': browse,
                   'probe': lambda: tell('Η παρακολούθηση αναπαραγωγής λειτουργεί.' if state() else 'Η παρακολούθηση αναπαραγωγής δεν είναι διαθέσιμη.')}
        if mode in actions:
            actions[mode]()
    except Exception as exc:
        # Never expose exception strings, playing URLs, subprocess command lines or subtitle paths.
        code = str(exc) if type(exc) in (ValueError, RuntimeError) and str(exc) in {
            'local-reference-required', 'selection-changed', 'playback-changed', 'playback-monitor-unavailable'} else type(exc).__name__
        messages = {'local-reference-required': 'Ο συγχρονισμός λειτουργεί μόνο με βίντεο αποθηκευμένο σε αυτή τη συσκευή, όχι με ροή από το διαδίκτυο.',
                    'selection-changed': 'Άλλαξε η αναπαραγωγή ή ο υπότιτλος. Η εργασία σταμάτησε.',
                    'playback-changed': 'Άλλαξε η αναπαραγωγή. Η εργασία σταμάτησε.',
                    'playback-monitor-unavailable': 'Η παρακολούθηση αναπαραγωγής δεν είναι διαθέσιμη. Κάνε επανεκκίνηση του Kodi.'}
        tell(messages.get(code, 'Η εργασία δεν ολοκληρώθηκε. Έλεγξε τον ενεργό υπότιτλο. Κωδικός: '+code))
    finally:
        lock.unlink(missing_ok=True)

if __name__ == '__main__':
    main()
