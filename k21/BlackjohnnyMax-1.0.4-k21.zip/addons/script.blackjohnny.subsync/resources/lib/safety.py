"""Local, bounded SRT validation. No Kodi imports or network access."""
import hashlib
import os
import re
from pathlib import Path

MAX_BYTES = 8 * 1024 * 1024
TIMING = re.compile(r'^(\d{1,3}):(\d{2}):(\d{2}),(\d{3})\s*-->\s*(\d{1,3}):(\d{2}):(\d{2}),(\d{3})(?:\s+.*)?$')

def digest(data):
    return hashlib.sha256(data).hexdigest()

def validate_srt(data):
    if not data or len(data) > MAX_BYTES:
        raise ValueError('srt-size')
    text = None
    for encoding in ('utf-8-sig', 'utf-16' if data[:2] in (b'\xff\xfe', b'\xfe\xff') else 'cp1253'):
        try:
            text = data.decode(encoding)
            break
        except UnicodeError:
            pass
    if text is None or '\x00' in text:
        raise ValueError('srt-encoding')
    blocks = re.split(r'\n\s*\n', text.replace('\r\n', '\n').replace('\r', '\n').strip())
    cues = 0
    for block in blocks:
        lines = block.strip().splitlines()
        if not lines:
            continue
        pos = 1 if lines[0].strip().isdigit() else 0
        if len(lines) < pos + 2:
            raise ValueError('srt-cue')
        match = TIMING.fullmatch(lines[pos].strip())
        if not match:
            raise ValueError('srt-timing')
        n = list(map(int, match.groups()))
        if any(n[i] >= 60 for i in (1, 2, 5, 6)):
            raise ValueError('srt-range')
        start = n[0]*3600000+n[1]*60000+n[2]*1000+n[3]
        end = n[4]*3600000+n[5]*60000+n[6]*1000+n[7]
        if end <= start or not ''.join(lines[pos+1:]).strip():
            raise ValueError('srt-interval')
        cues += 1
    if not cues:
        raise ValueError('srt-empty')
    return cues

def read_srt(path):
    p = Path(path)
    if p.suffix.lower() != '.srt' or p.is_symlink():
        raise ValueError('srt-path')
    with p.open('rb') as f:
        a = os.fstat(f.fileno())
        data = f.read(MAX_BYTES + 1)
        b = os.fstat(f.fileno())
    if (a.st_size, a.st_mtime_ns) != (b.st_size, b.st_mtime_ns):
        raise ValueError('srt-changing')
    cues = validate_srt(data)
    return data, {'sha256': digest(data), 'size': len(data), 'mtime_ns': b.st_mtime_ns, 'cues': cues}

def eligible(snapshot, session, now, ttl=900):
    age = now - snapshot.get('created', -1e12)
    return bool(session and snapshot.get('session') == session and 0 <= age <= ttl)

def changed_candidates(before, after):
    # A change identifies candidates, NOT which stream Kodi loaded.
    return [p for p, r in after.items() if p not in before or before[p].get('sha256') != r.get('sha256')]

def same_playback(a, b):
    return bool(a and b and a.get('session') and all(a.get(k) == b.get(k) for k in ('session', 'file', 'playerid')))

def same_selection(a, b):
    return same_playback(a, b) and a.get('subtitle') == b.get('subtitle') and a.get('enabled') == b.get('enabled')
