#!/usr/bin/env python3
# -*- coding: utf-8 -*-
from __future__ import annotations
import argparse, json, os, sys, tempfile, time
from pathlib import Path

def atomic_json(path, obj):
    path = Path(path); path.parent.mkdir(parents=True, exist_ok=True)
    fd, tmp = tempfile.mkstemp(prefix=path.name+".", suffix=".tmp", dir=str(path.parent))
    os.close(fd)
    try:
        Path(tmp).write_text(json.dumps(obj, ensure_ascii=False, indent=2), encoding="utf-8")
        os.replace(tmp, path)
    finally:
        try:
            if os.path.exists(tmp): os.unlink(tmp)
        except OSError:
            pass

def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--result")
    ap.add_argument("--self-test", action="store_true")
    ap.add_argument("--progress")
    ns = ap.parse_args()

    if ns.self_test:
        import inspect
        import imageio_ffmpeg
        import ffsubsync
        from ffsubsync.ffsubsync import make_parser
        assert os.path.isfile(imageio_ffmpeg.get_ffmpeg_exe()), "ffmpeg-missing"
        parser = make_parser()
        required = {"--ffmpeg-path", "--skip-sync-on-low-quality", "--quality-max-offset-seconds",
                    "--max-framerate-deviation", "--max-duration-seconds", "--start-seconds", "--vad"}
        assert required <= set(parser._option_string_actions), "engine-options-incompatible"
        assert "progress_handler" in inspect.signature(ffsubsync.run).parameters, "engine-api-incompatible"
        parser.parse_args(["reference.mkv", "-i", "source.srt", "-o", "output.srt", "--vad", "webrtc"])
        print("ENGINE CONTRACT PASS")
        return 0
    if not ns.result or not ns.progress:
        ap.error("result/progress required")
    request = json.loads(sys.stdin.read())
    reference = request["reference"]
    subtitle = request["subtitle"]
    output = request["output"]

    atomic_json(ns.progress, {"state":"starting","fraction":0.0})
    try:
        import imageio_ffmpeg
        from ffsubsync.ffsubsync import make_parser
        import ffsubsync

        argv = [
            reference, "-i", subtitle, "-o", output,
            "--ffmpeg-path", imageio_ffmpeg.get_ffmpeg_exe(),
            "--vad", "webrtc",
            "--skip-sync-on-low-quality",
            "--quality-max-offset-seconds", str(request.get("quality_max_offset_seconds",30)),
            "--max-framerate-deviation", str(request.get("max_framerate_deviation",0.05)),
            "--max-duration-seconds", str(request.get("max_duration_seconds",900)),
            "--start-seconds", str(request.get("start_seconds",30)),
        ]
        args = make_parser().parse_args(argv)
        last = [0.0]
        def progress(info):
            now = time.time()
            if now-last[0] < .2: return
            last[0] = now
            f = getattr(info,"fraction",None)
            atomic_json(ns.progress,{
                "state":"analyzing",
                "fraction":float(f) if f is not None else None,
                "processed_seconds":getattr(info,"processed_seconds",None),
                "total_seconds":getattr(info,"total_seconds",None),
            })
        result = ffsubsync.run(args, progress_handler=progress)
        safe = {
            "retval":int(result.get("retval",1)),
            "sync_was_successful":bool(result.get("sync_was_successful",False)),
            "offset_seconds":float(result["offset_seconds"]) if result.get("offset_seconds") is not None else None,
            "framerate_scale_factor":float(result["framerate_scale_factor"]) if result.get("framerate_scale_factor") is not None else None,
            "output_exists":os.path.isfile(output),
        }
        atomic_json(ns.result,safe)
        atomic_json(ns.progress,{"state":"done","fraction":1.0})
        return 0 if safe["sync_was_successful"] and safe["output_exists"] else 3
    except Exception as exc:
        atomic_json(ns.result,{
            "retval":2,"sync_was_successful":False,
            "error":type(exc).__name__,
            "output_exists":os.path.isfile(output),
        })
        atomic_json(ns.progress,{"state":"failed","fraction":None})
        return 2

if __name__=="__main__":
    raise SystemExit(main())
