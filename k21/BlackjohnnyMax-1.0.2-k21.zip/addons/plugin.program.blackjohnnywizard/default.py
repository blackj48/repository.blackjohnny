#!/usr/bin/env python3
"""BLACKJOHNNY MAX Wizard - entry point."""

import sys

from resources.lib import gui, installer, backup, cleaner, ledger, log


def parse_args(argv):
    args = {}
    for item in argv[1:]:
        if "=" in item:
            k, _, v = item.partition("=")
            args[k.strip()] = v.strip()
    return args


def main(argv):
    logger = log.Logger()
    ui = gui.WizardGUI()

    # Crash recovery runs before anything else touches the filesystem.
    # A ledger entry left open means a previous install died mid-commit.
    pending = ledger.Ledger(logger).find_incomplete()
    if pending:
        logger.warning("incomplete install found: {0}".format(pending.txn_id))
        if ui.confirm(
            "Βρέθηκε ημιτελής εγκατάσταση από προηγούμενη συνεδρία.\n"
            "Πρέπει να γίνει επαναφορά πριν συνεχίσουμε.\n\nΝα γίνει τώρα;"
        ):
            installer.Installer(ui, logger).rollback(pending)
        else:
            ui.error("Η επαναφορά αναβλήθηκε. Η εγκατάσταση μπορεί να είναι ασυνεπής.")
            return

    args = parse_args(argv)
    action = args.get("action")

    if action == "backup":
        backup.BackupManager(ui, logger).create()
        return
    if action == "restore":
        backup.BackupManager(ui, logger).restore()
        return
    if action == "check_updates":
        installer.Installer(ui, logger).check_updates()
        return
    if action == "clean":
        cleaner.Cleaner(ui, logger).run()
        return

    menu(ui, logger)


def menu(ui, logger):
    options = [
        "Εγκατάσταση / Ενημέρωση",
        "Backup",
        "Επαναφορά",
        "Καθαρισμός",
        "Ρυθμίσεις",
    ]
    while True:
        choice = ui.select("BLACKJOHNNY MAX Wizard", options)
        if choice == 0:
            installer.Installer(ui, logger).install()
        elif choice == 1:
            backup.BackupManager(ui, logger).create()
        elif choice == 2:
            backup.BackupManager(ui, logger).restore()
        elif choice == 3:
            cleaner.Cleaner(ui, logger).run()
        elif choice == 4:
            ui.open_settings()
        else:
            break


if __name__ == "__main__":
    main(sys.argv)
