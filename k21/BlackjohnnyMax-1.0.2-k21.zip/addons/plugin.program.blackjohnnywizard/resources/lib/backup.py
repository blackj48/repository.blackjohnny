"""Backup and restore.

The original zipped the whole of special://userdata/. That means Thumbnails/
(routinely 1-5 GB), plus Database/*.db which Kodi holds open - they get archived
in an inconsistent state and restoring them can corrupt the library.

This uses an explicit whitelist and writes a manifest into the archive.
"""

import json
import os
import shutil
import time
import zipfile

import xbmc

from . import paths

# Relative to special://userdata/
WHITELIST_FILES = [
    "guisettings.xml",
    "sources.xml",
    "favourites.xml",
    "advancedsettings.xml",
    "mediasources.xml",
    "passwords.xml",
    "profiles.xml",
    "RssFeeds.xml",
]

WHITELIST_DIRS = [
    "keymaps",
    "playlists",
    "addon_data",
]

# Never archived, even under a whitelisted directory
EXCLUDE_SUFFIXES = (".db", ".db-journal", ".db-wal", ".log", ".pyc")
EXCLUDE_DIRS = {"Thumbnails", "Database", "__pycache__", "cache", "temp"}

MANIFEST_NAME = "bjmax_backup_manifest.json"


class BackupManager:
    def __init__(self, ui, logger):
        self.ui = ui
        self.log = logger
        paths.ensure_dirs()

    # ------------------------------------------------------------ create
    def create(self, silent=False):
        stamp = time.strftime("%Y%m%d_%H%M%S")
        name = "BJMAX_backup_{0}".format(stamp)
        archive = os.path.join(paths.BACKUPS, name + ".zip")

        try:
            if not silent:
                self.ui.progress_start("Backup", "Συλλογή αρχείων...")

            entries = list(self._collect())
            if not entries:
                raise RuntimeError("Δεν βρέθηκε τίποτα προς αποθήκευση.")

            manifest = {
                "name": name,
                "created": time.time(),
                "created_human": time.strftime("%Y-%m-%d %H:%M:%S"),
                "kodi_version": xbmc.getInfoLabel("System.BuildVersion"),
                "build_version": paths.ADDON.getSetting("installed_build_version"),
                "file_count": len(entries),
                "files": [rel for _abs, rel in entries],
            }

            total = len(entries)
            with zipfile.ZipFile(archive, "w", zipfile.ZIP_DEFLATED) as zf:
                zf.writestr(MANIFEST_NAME, json.dumps(manifest, indent=2, ensure_ascii=False))
                for i, (abs_path, rel) in enumerate(entries):
                    if not silent and i % 25 == 0:
                        self.ui.progress_update(100.0 * i / total, rel)
                    try:
                        zf.write(abs_path, rel)
                    except OSError as exc:
                        self.log.warning("backup: skipped {0}: {1}".format(rel, exc))

            size_mb = os.path.getsize(archive) / 1048576.0
            if not silent:
                self.ui.progress_close()
                self.ui.success("Το backup δημιουργήθηκε:\n{0}\n\n"
                                "{1} αρχεία, {2:.1f} MB".format(name, total, size_mb))
            self.log.info("backup created: {0} ({1} files, {2:.1f} MB)".format(
                name, total, size_mb))
            self._prune()
            return True

        except Exception as exc:  # noqa: BLE001
            if not silent:
                self.ui.progress_close()
                self.ui.error("Σφάλμα backup:\n{0}".format(exc))
            self.log.error("backup failed: {0}".format(exc))
            try:
                if os.path.isfile(archive):
                    os.remove(archive)
            except OSError:
                pass
            return False

    def _collect(self):
        root = paths.KODI_USERDATA
        for rel in WHITELIST_FILES:
            abs_path = os.path.join(root, rel)
            if os.path.isfile(abs_path):
                yield abs_path, rel

        for rel_dir in WHITELIST_DIRS:
            base = os.path.join(root, rel_dir)
            if not os.path.isdir(base):
                continue
            for dirpath, dirnames, filenames in os.walk(base):
                dirnames[:] = [d for d in dirnames if d not in EXCLUDE_DIRS]
                for name in filenames:
                    if name.endswith(EXCLUDE_SUFFIXES):
                        continue
                    abs_path = os.path.join(dirpath, name)
                    yield abs_path, os.path.relpath(abs_path, root)

    def _prune(self, keep=5):
        try:
            archives = sorted(
                (f for f in os.listdir(paths.BACKUPS) if f.endswith(".zip")),
                reverse=True)
            for old in archives[keep:]:
                os.remove(os.path.join(paths.BACKUPS, old))
                self.log.info("backup pruned: {0}".format(old))
        except OSError as exc:
            self.log.warning("prune failed: {0}".format(exc))

    # ------------------------------------------------------------ restore
    def restore(self):
        archives = self._list_archives()
        if not archives:
            self.ui.error("Δεν βρέθηκαν backups.")
            return False

        labels = []
        for path in archives:
            manifest = self._read_manifest(path)
            labels.append("{0}  ({1} αρχεία)".format(
                manifest.get("created_human", os.path.basename(path)),
                manifest.get("file_count", "?")))

        # NOTE: self.ui.select, not self.dialog.select. The original called
        # self.dialog on a class that had no such attribute - restore raised
        # AttributeError unconditionally.
        idx = self.ui.select("Επιλογή backup", labels)
        if idx < 0:
            return False

        archive = archives[idx]

        if not self.ui.confirm(
            "Η επαναφορά θα αντικαταστήσει τις τρέχουσες ρυθμίσεις.\n"
            "Θα κρατηθεί αντίγραφο ασφαλείας της τωρινής κατάστασης πρώτα.\n\n"
            "Να συνεχίσουμε;"
        ):
            return False

        if not self.create(silent=True):
            if not self.ui.confirm("Το προστατευτικό backup απέτυχε.\n"
                                   "Να συνεχίσουμε ΧΩΡΙΣ αυτό;"):
                return False

        try:
            self.ui.progress_start("Επαναφορά", "Εξαγωγή...")
            with zipfile.ZipFile(archive, "r") as zf:
                names = [n for n in zf.namelist() if n != MANIFEST_NAME]
                total = len(names)
                root = os.path.abspath(paths.KODI_USERDATA)

                for i, member in enumerate(names):
                    dest = os.path.abspath(os.path.join(root, member))
                    if not dest.startswith(root + os.sep):
                        self.log.warning("restore: rejected unsafe path {0}".format(member))
                        continue
                    self.ui.progress_update(100.0 * i / max(total, 1), member)
                    os.makedirs(os.path.dirname(dest), exist_ok=True)
                    with zf.open(member) as src, open(dest, "wb") as out:
                        shutil.copyfileobj(src, out)

            self.ui.progress_update(100, "Ολοκληρώθηκε")
            xbmc.sleep(600)
            self.ui.progress_close()
            self.log.info("restore complete from {0}".format(os.path.basename(archive)))

            if self.ui.confirm("Η επαναφορά ολοκληρώθηκε.\n\n"
                               "Απαιτείται επανεκκίνηση.\nΝα γίνει τώρα;"):
                xbmc.executebuiltin("RestartApp")
            return True

        except Exception as exc:  # noqa: BLE001
            self.ui.progress_close()
            self.log.error("restore failed: {0}".format(exc))
            self.ui.error("Σφάλμα επαναφοράς:\n{0}".format(exc))
            return False

    def _list_archives(self):
        if not os.path.isdir(paths.BACKUPS):
            return []
        files = [os.path.join(paths.BACKUPS, f)
                 for f in os.listdir(paths.BACKUPS) if f.endswith(".zip")]
        return sorted(files, reverse=True)

    def _read_manifest(self, archive):
        try:
            with zipfile.ZipFile(archive, "r") as zf:
                if MANIFEST_NAME in zf.namelist():
                    return json.loads(zf.read(MANIFEST_NAME).decode("utf-8"))
        except (OSError, ValueError, zipfile.BadZipFile):
            pass
        return {}
