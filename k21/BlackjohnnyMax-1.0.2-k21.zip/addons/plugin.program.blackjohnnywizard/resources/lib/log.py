"""Wizard logging."""

import os
import time

import xbmc

from . import paths


class Logger:
    def __init__(self, path=None):
        self.path = path or paths.LOG_FILE
        os.makedirs(os.path.dirname(self.path), exist_ok=True)

    def _write(self, level, message):
        line = "[{0}] [{1}] {2}\n".format(
            time.strftime("%Y-%m-%d %H:%M:%S"), level, message)
        try:
            with open(self.path, "a", encoding="utf-8") as fh:
                fh.write(line)
        except OSError:
            pass
        xbmc.log("{0}: {1}".format(paths.ADDON_ID, message),
                 xbmc.LOGERROR if level == "ERROR" else xbmc.LOGINFO)

    def info(self, m):
        self._write("INFO", m)

    def warning(self, m):
        self._write("WARNING", m)

    def error(self, m):
        self._write("ERROR", m)
