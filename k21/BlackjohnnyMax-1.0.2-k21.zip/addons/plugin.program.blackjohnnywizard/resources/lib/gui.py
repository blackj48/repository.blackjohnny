"""Wizard user interface.

The dialog object lives here and only here. The original had BackupManager
reach for self.dialog, which it never had - restore_backup() raised
AttributeError every single time, in exactly the feature that is the user's
safety net.
"""

import xbmcgui

from . import paths


class WizardGUI:
    def __init__(self):
        self.dialog = xbmcgui.Dialog()
        self._progress = None

    # -- input -----------------------------------------------------
    def select(self, heading, options):
        return self.dialog.select(heading, options)

    def confirm(self, message, heading="Επιβεβαίωση"):
        return self.dialog.yesno(heading, message)

    def browse_file(self, heading, mask=".zip"):
        return self.dialog.browse(1, heading, "files", mask)

    # -- output ----------------------------------------------------
    def error(self, message, heading="Σφάλμα"):
        self.dialog.ok(heading, message)

    def success(self, message, heading="Επιτυχία"):
        self.dialog.ok(heading, message)

    def notify(self, message, heading="BLACKJOHNNY MAX"):
        self.dialog.notification(heading, message, xbmcgui.NOTIFICATION_INFO, 5000)

    # -- progress --------------------------------------------------
    def progress_start(self, heading, message=""):
        self._progress = xbmcgui.DialogProgress()
        self._progress.create(heading, message)

    def progress_update(self, percent, message=""):
        if self._progress:
            self._progress.update(int(percent), message)

    def progress_cancelled(self):
        return bool(self._progress and self._progress.iscanceled())

    def progress_close(self):
        if self._progress:
            self._progress.close()
            self._progress = None

    def open_settings(self):
        paths.ADDON.openSettings()
