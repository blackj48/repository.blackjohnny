"""Atomic build installation."""

import hashlib
import json
import os
import shutil
import urllib.error
import urllib.request
import zipfile

import xbmc
import xbmcvfs

from . import ledger as ledger_mod
from . import paths

USER_AGENT = "BLACKJOHNNY-MAX-Wizard/1.0"
CHUNK = 65536


class Installer:
    def __init__(self, ui, logger):
        self.ui = ui
        self.log = logger
        self.ledger = ledger_mod.Ledger(logger)
        paths.ensure_dirs()

    # ============================================================ public
    def check_updates(self):
        builds = self._fetch_builds()
        if not builds:
            return
        current = paths.ADDON.getSetting("installed_build_version")
        latest = builds[0].get("version", "")
        if latest and latest != current:
            if self.ui.confirm("Διαθέσιμη έκδοση: {0}\nΕγκατεστημένη: {1}\n\n"
                               "Να γίνει ενημέρωση;".format(latest, current or "-")):
                self.install(builds[0])
        else:
            self.ui.success("Είσαι στην τελευταία έκδοση ({0}).".format(current or latest))

    def install(self, build_info=None):
        if build_info is None:
            build_info = self._choose_build()
            if build_info is None:
                return False

        version = build_info.get("version", "?")
        url = build_info.get("url", "")
        expected = build_info.get("checksum", "")

        if not url:
            self.ui.error("Το build δεν έχει URL λήψης.")
            return False

        if not self.ui.confirm(
            "Έκδοση: {0}\nΚατάσταση: {1}\n\n"
            "Θα δημιουργηθεί αυτόματα backup πριν την εγκατάσταση.\n"
            "Να συνεχίσουμε;".format(version, build_info.get("status", "unknown"))
        ):
            return False

        # Backup first. Non-negotiable.
        from . import backup as backup_mod
        if not backup_mod.BackupManager(self.ui, self.log).create(silent=True):
            if not self.ui.confirm("Το αυτόματο backup απέτυχε.\n"
                                   "Να συνεχίσουμε ΧΩΡΙΣ backup;"):
                return False

        archive = os.path.join(paths.DOWNLOADS, "bjmax-{0}.zip".format(version))
        if not self._download(url, archive):
            return False

        if expected and not self._verify(archive, expected):
            self.ui.error("Ο έλεγχος ακεραιότητας απέτυχε.\n"
                          "Το αρχείο είναι κατεστραμμένο ή αλλοιωμένο.\n"
                          "Η εγκατάσταση ακυρώθηκε.")
            self._safe_remove(archive)
            return False

        ok = self._install_atomic(archive, version)
        self._safe_remove(archive)
        return ok

    # ============================================================ pipeline
    def _install_atomic(self, archive, version):
        """STAGE -> VALIDATE -> JOURNAL -> COMMIT -> VERIFY, with rollback."""
        staging = os.path.join(paths.STAGING, version)
        entry = None

        try:
            # ---- 1. STAGE -------------------------------------------------
            self.ui.progress_start("Εγκατάσταση", "Εξαγωγή σε staging...")
            if os.path.isdir(staging):
                shutil.rmtree(staging, ignore_errors=True)
            os.makedirs(staging, exist_ok=True)

            with zipfile.ZipFile(archive, "r") as zf:
                self._safe_extract(zf, staging)

            # ---- 2. VALIDATE ----------------------------------------------
            self.ui.progress_update(20, "Έλεγχος πακέτου...")
            addons = self._validate_staging(staging)
            if not addons:
                raise RuntimeError("Το πακέτο δεν περιέχει έγκυρα add-ons.")

            # ---- 3. JOURNAL -----------------------------------------------
            entry = self.ledger.begin()

            # ---- 4. COMMIT ------------------------------------------------
            total = len(addons)
            for i, (addon_id, src) in enumerate(addons):
                pct = 25 + int(60.0 * i / total)
                self.ui.progress_update(pct, "Εγκατάσταση {0}...".format(addon_id))

                dst = os.path.join(paths.KODI_ADDONS, addon_id)
                bak = dst + ".bjbak"

                if os.path.isdir(bak):
                    shutil.rmtree(bak, ignore_errors=True)

                if os.path.isdir(dst):
                    # os.replace on a directory is atomic within a filesystem
                    # and, unlike rmtree, does not need the files unlocked.
                    os.replace(dst, bak)
                    self.ledger.record(entry, "replace", dst, bak)
                else:
                    self.ledger.record(entry, "create", dst, None)

                shutil.move(src, dst)

                # ---- 5. VERIFY --------------------------------------------
                if not os.path.isfile(os.path.join(dst, "addon.xml")):
                    raise RuntimeError(
                        "Επαλήθευση απέτυχε για {0}: λείπει addon.xml".format(addon_id))

            # ---- userdata -------------------------------------------------
            self.ui.progress_update(88, "Εφαρμογή ρυθμίσεων...")
            self._install_userdata(staging, entry)

            # ---- 6a. SUCCESS ----------------------------------------------
            self.ledger.commit(entry)
            self._cleanup_backups(entry)
            self.ledger.close(entry)

            paths.ADDON.setSetting("installed_build_version", version)

            self.ui.progress_update(100, "Ολοκληρώθηκε")
            xbmc.sleep(600)
            self.ui.progress_close()

            if self.ui.confirm("Η εγκατάσταση της έκδοσης {0} ολοκληρώθηκε.\n\n"
                               "Απαιτείται επανεκκίνηση του Kodi.\n"
                               "Να γίνει τώρα;".format(version)):
                xbmc.executebuiltin("RestartApp")
            return True

        except Exception as exc:  # noqa: BLE001
            # ---- 6b. FAIL -------------------------------------------------
            self.ui.progress_close()
            self.log.error("install failed: {0}".format(exc))
            if entry is not None:
                self.rollback(entry)
                self.ui.error("Η εγκατάσταση απέτυχε:\n{0}\n\n"
                              "Έγινε επαναφορά στην προηγούμενη κατάσταση.".format(exc))
            else:
                self.ui.error("Η εγκατάσταση απέτυχε πριν αλλάξει οτιδήποτε:\n{0}\n\n"
                              "Το σύστημα δεν επηρεάστηκε.".format(exc))
            return False

        finally:
            shutil.rmtree(staging, ignore_errors=True)

    def rollback(self, entry):
        """Undo a transaction in reverse order. Best effort per operation:
        one failure must not stop the rest from being restored."""
        self.log.warning("rolling back transaction {0}".format(entry.txn_id))
        self.ui.progress_start("Επαναφορά", "Αναίρεση αλλαγών...")

        ops = list(reversed(entry.operations))
        for i, op in enumerate(ops):
            self.ui.progress_update(100.0 * i / max(len(ops), 1),
                                    os.path.basename(op["target"]))
            try:
                target = op["target"]
                if op["op"] == "create":
                    shutil.rmtree(target, ignore_errors=True)
                elif op["op"] == "replace" and op.get("backup"):
                    shutil.rmtree(target, ignore_errors=True)
                    if os.path.isdir(op["backup"]):
                        os.replace(op["backup"], target)
                elif op["op"] == "file_replace" and op.get("backup"):
                    if os.path.isfile(op["backup"]):
                        shutil.copy2(op["backup"], target)
                        os.remove(op["backup"])
            except OSError as exc:
                self.log.error("rollback step failed for {0}: {1}".format(
                    op.get("target"), exc))

        self.ledger.close(entry)
        self.ui.progress_close()
        self.log.info("rollback complete")

    # ============================================================ helpers
    def _choose_build(self):
        builds = self._fetch_builds()
        if not builds:
            return None
        labels = ["{0}  ({1})".format(b.get("version", "?"), b.get("status", "?"))
                  for b in builds]
        idx = self.ui.select("Επιλογή build", labels)
        return builds[idx] if idx >= 0 else None

    def _fetch_builds(self):
        if not paths.BUILD_SERVER:
            self.ui.error("Δεν έχει οριστεί build server.\n"
                          "Όρισέ τον στις ρυθμίσεις του wizard.")
            return []
        try:
            req = urllib.request.Request(paths.builds_json_url(),
                                         headers={"User-Agent": USER_AGENT})
            with urllib.request.urlopen(req, timeout=30) as resp:
                data = json.loads(resp.read().decode("utf-8"))
            return data.get("builds", [])
        except (urllib.error.URLError, ValueError, OSError) as exc:
            self.log.error("build list fetch failed: {0}".format(exc))
            self.ui.error("Δεν ήταν δυνατή η σύνδεση με τον build server:\n{0}".format(exc))
            return []

    def _download(self, url, destination):
        try:
            self.ui.progress_start("Λήψη", "Σύνδεση...")
            os.makedirs(os.path.dirname(destination), exist_ok=True)
            req = urllib.request.Request(url, headers={"User-Agent": USER_AGENT})

            with urllib.request.urlopen(req, timeout=60) as resp:
                total = int(resp.headers.get("Content-Length") or 0)
                done = 0
                with open(destination, "wb") as fh:
                    while True:
                        if self.ui.progress_cancelled():
                            raise RuntimeError("Ακυρώθηκε από τον χρήστη")
                        chunk = resp.read(CHUNK)
                        if not chunk:
                            break
                        fh.write(chunk)
                        done += len(chunk)
                        if total:
                            self.ui.progress_update(
                                100.0 * done / total,
                                "{0:.1f} / {1:.1f} MB".format(
                                    done / 1048576.0, total / 1048576.0))
            self.ui.progress_close()
            return True
        except Exception as exc:  # noqa: BLE001
            self.ui.progress_close()
            self._safe_remove(destination)
            self.log.error("download failed: {0}".format(exc))
            self.ui.error("Η λήψη απέτυχε:\n{0}".format(exc))
            return False

    def _verify(self, path, expected):
        self.ui.progress_start("Επαλήθευση", "Έλεγχος ακεραιότητας...")
        digest = hashlib.sha256()
        try:
            with open(path, "rb") as fh:
                for block in iter(lambda: fh.read(CHUNK), b""):
                    digest.update(block)
        except OSError:
            self.ui.progress_close()
            return False
        self.ui.progress_close()
        return digest.hexdigest().lower() == expected.strip().lower()

    @staticmethod
    def _safe_extract(zf, target):
        """Reject path traversal. A build zip is remote input; treat it as hostile."""
        target = os.path.abspath(target)
        for member in zf.namelist():
            dest = os.path.abspath(os.path.join(target, member))
            if not dest.startswith(target + os.sep) and dest != target:
                raise RuntimeError("Μη ασφαλής διαδρομή στο αρχείο: {0}".format(member))
        zf.extractall(target)

    def _validate_staging(self, staging):
        """Return [(addon_id, source_dir)] for every valid add-on in staging."""
        addons_root = os.path.join(staging, "addons")
        if not os.path.isdir(addons_root):
            return []

        found = []
        for name in sorted(os.listdir(addons_root)):
            src = os.path.join(addons_root, name)
            if not os.path.isdir(src):
                continue
            if not os.path.isfile(os.path.join(src, "addon.xml")):
                self.log.warning("staging: skipping {0}, no addon.xml".format(name))
                continue
            found.append((name, src))
        self.log.info("staging: {0} valid add-ons".format(len(found)))
        return found

    def _install_userdata(self, staging, entry):
        src_root = os.path.join(staging, "userdata")
        if not os.path.isdir(src_root):
            return
        for root, _dirs, files in os.walk(src_root):
            for name in files:
                src = os.path.join(root, name)
                rel = os.path.relpath(src, src_root)
                dst = os.path.join(paths.KODI_USERDATA, rel)
                os.makedirs(os.path.dirname(dst), exist_ok=True)
                if os.path.isfile(dst):
                    bak = dst + ".bjbak"
                    shutil.copy2(dst, bak)
                    self.ledger.record(entry, "file_replace", dst, bak)
                else:
                    self.ledger.record(entry, "create", dst, None)
                shutil.copy2(src, dst)

    def _cleanup_backups(self, entry):
        for op in entry.operations:
            bak = op.get("backup")
            if not bak:
                continue
            try:
                if os.path.isdir(bak):
                    shutil.rmtree(bak, ignore_errors=True)
                elif os.path.isfile(bak):
                    os.remove(bak)
            except OSError as exc:
                self.log.warning("could not remove backup {0}: {1}".format(bak, exc))

    @staticmethod
    def _safe_remove(path):
        try:
            if os.path.isfile(path):
                os.remove(path)
        except OSError:
            pass
