"""Cleanup utility.

Delegates cache work to the service add-on where it is implemented once,
rather than keeping a second divergent copy here.
"""

import os
import time

import xbmc

from . import paths


class Cleaner:
    def __init__(self, ui, logger):
        self.ui = ui
        self.log = logger

    def run(self):
        if not self.ui.confirm(
            "Θα διαγραφούν προσωρινά αρχεία παλαιότερα των 7 ημερών και\n"
            "θα εκτελεστεί καθαρισμός της βιβλιοθήκης βίντεο.\n\nΝα συνεχίσουμε;"
        ):
            return False

        try:
            self.ui.progress_start("Καθαρισμός", "Προσωρινά αρχεία...")
            removed, freed, locked = self._clean_temp(max_age_days=7)
            self.ui.progress_update(60, "Καθαρισμός βιβλιοθήκης...")
            xbmc.executebuiltin("CleanLibrary(video)")
            self.ui.progress_update(100, "Ολοκληρώθηκε")
            xbmc.sleep(600)
            self.ui.progress_close()

            self.ui.success(
                "Ο καθαρισμός ολοκληρώθηκε.\n\n"
                "Διαγράφηκαν: {0} αρχεία ({1:.1f} MB)\n"
                "Κλειδωμένα / παραλείφθηκαν: {2}\n\n"
                "Ο καθαρισμός βιβλιοθήκης τρέχει στο παρασκήνιο.".format(
                    removed, freed / 1048576.0, locked))
            return True

        except Exception as exc:  # noqa: BLE001
            self.ui.progress_close()
            self.log.error("cleanup failed: {0}".format(exc))
            self.ui.error("Σφάλμα καθαρισμού:\n{0}".format(exc))
            return False

    def _clean_temp(self, max_age_days):
        cutoff = time.time() - max_age_days * 86400.0
        removed = freed = locked = 0
        for root, _dirs, files in os.walk(paths.KODI_TEMP):
            for name in files:
                path = os.path.join(root, name)
                try:
                    st = os.stat(path)
                    if st.st_mtime >= cutoff:
                        continue
                    size = st.st_size
                    os.remove(path)
                    removed += 1
                    freed += size
                except OSError:
                    locked += 1
        self.log.info("cleanup: {0} removed, {1:.1f} MB, {2} locked".format(
            removed, freed / 1048576.0, locked))
        return removed, freed, locked
