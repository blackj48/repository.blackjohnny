"""Crash-safe install ledger.

Why this exists: the original installer did shutil.rmtree() over live add-on
directories while Kodi was running. On Windows, loaded modules are locked, so
the delete fails partway through - with the add-on already gone and no way back.

The ledger records intent before any destructive step, and survives a crash.
On the next launch the wizard finds the open entry and completes the rollback
before doing anything else.
"""

import json
import os
import time
import uuid

from . import paths


class Entry:
    def __init__(self, txn_id, state="OPEN", operations=None, started=None):
        self.txn_id = txn_id
        self.state = state
        self.operations = operations or []
        self.started = started or time.time()

    def to_dict(self):
        return {
            "txn_id": self.txn_id,
            "state": self.state,
            "operations": self.operations,
            "started": self.started,
        }

    @classmethod
    def from_dict(cls, d):
        return cls(d["txn_id"], d.get("state", "OPEN"),
                   d.get("operations", []), d.get("started"))


class Ledger:
    """Single-entry ledger. One install transaction at a time, by design."""

    def __init__(self, logger):
        self.log = logger
        self.path = paths.LEDGER_FILE

    # -- persistence -----------------------------------------------
    def _read(self):
        try:
            if not os.path.exists(self.path):
                return None
            with open(self.path, "r", encoding="utf-8") as fh:
                return Entry.from_dict(json.load(fh))
        except (OSError, ValueError, KeyError) as exc:
            self.log.error("ledger unreadable: {0}".format(exc))
            return None

    def _write(self, entry):
        """Atomic write: temp file, fsync, rename. A half-written ledger is
        worse than none, because rollback would act on wrong information."""
        os.makedirs(os.path.dirname(self.path), exist_ok=True)
        tmp = self.path + ".tmp"
        with open(tmp, "w", encoding="utf-8") as fh:
            json.dump(entry.to_dict(), fh, indent=2)
            fh.flush()
            os.fsync(fh.fileno())
        os.replace(tmp, self.path)

    # -- lifecycle -------------------------------------------------
    def begin(self):
        entry = Entry(uuid.uuid4().hex[:12])
        self._write(entry)
        self.log.info("ledger: transaction {0} opened".format(entry.txn_id))
        return entry

    def record(self, entry, op, target, backup_path=None):
        entry.operations.append({
            "op": op,
            "target": target,
            "backup": backup_path,
            "ts": time.time(),
        })
        self._write(entry)

    def commit(self, entry):
        entry.state = "COMMITTED"
        self._write(entry)
        self.log.info("ledger: transaction {0} committed".format(entry.txn_id))

    def close(self, entry):
        try:
            os.remove(self.path)
        except OSError:
            pass
        self.log.info("ledger: transaction {0} closed".format(entry.txn_id))

    def find_incomplete(self):
        entry = self._read()
        if entry and entry.state == "OPEN":
            return entry
        return None
