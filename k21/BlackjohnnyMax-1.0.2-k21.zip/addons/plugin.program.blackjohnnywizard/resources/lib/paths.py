"""Path constants. One place, so nothing guesses."""

import os

import xbmcaddon
import xbmcvfs

ADDON = xbmcaddon.Addon()
ADDON_ID = ADDON.getAddonInfo("id")

PROFILE = xbmcvfs.translatePath(ADDON.getAddonInfo("profile"))
DOWNLOADS = os.path.join(PROFILE, "downloads")
BACKUPS = os.path.join(PROFILE, "backups")
STAGING = os.path.join(PROFILE, "staging")
LEDGER_FILE = os.path.join(PROFILE, "install_ledger.json")
LOG_FILE = os.path.join(PROFILE, "wizard.log")

KODI_HOME = xbmcvfs.translatePath("special://home/")
KODI_ADDONS = xbmcvfs.translatePath("special://home/addons/")
KODI_USERDATA = xbmcvfs.translatePath("special://userdata/")
KODI_TEMP = xbmcvfs.translatePath("special://temp/")

# The build server origin. Read from settings so it is configurable per
# deployment rather than compiled in. Note: the original hardcoded
# https://builds.blackjohnny.max - '.max' is not a real TLD and never resolves.
BUILD_SERVER = ADDON.getSetting("build_server_url").rstrip("/")


def builds_json_url():
    return "{0}/builds.json".format(BUILD_SERVER)


def ensure_dirs():
    for path in (PROFILE, DOWNLOADS, BACKUPS, STAGING):
        os.makedirs(path, exist_ok=True)
